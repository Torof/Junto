/* Profile mock — before / after badge system */

const SCROTT_FIABILITE = { label: 'Bonne', pct: 80, completed: 69, created: 60, joined: 23 };

// ============================================================
// BEFORE — current implementation, with chiffres on badges
// ============================================================
const BEFORE_BADGES_COMMU = [
  { label:'De confia…', icon:'shield-check', count: 30, color:'#7EC8A3' },
  { label:'Super lea…', icon:'star',         count: 28, color:'#F26B2E' },
  { label:'Bonne a…',   icon:'smile',        count: 28, color:'#F4A373' },
  { label:'Ponctuel',   icon:'clock',        count: 28, color:'#A872D8' },
];
const BEFORE_BADGES_JUNTO = [
  { label:'Régulier',  icon:'bolt',      count: 20, color:'#F26B2E' },
  { label:'Animateur', icon:'star',      count: 49, color:'#F26B2E' },
  { label:'Curieux',   icon:'mountain',  count: 6,  color:'#7EC8A3' },
  { label:'Curieux',   icon:'wave',      count: 7,  color:'#5BA8D6' },
  { label:'Curieux',   icon:'mountain',  count: 7,  color:'#7EC8A3' },
  { label:'Mordu',     icon:'paraglide', count: 32, color:'#F26B2E' },
];

function BeforeBadge({ b }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 4, width: 64 }}>
      <div style={{ position:'relative' }}>
        <div style={{
          width: 50, height: 50, borderRadius:'50%',
          background: b.color,
          display:'flex', alignItems:'center', justifyContent:'center',
          boxShadow: `0 2px 8px -2px ${b.color}80`,
        }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2">
            {BADGE_ICON[b.icon]}
          </svg>
        </div>
        {/* count chip */}
        <div style={{
          position:'absolute', top: -3, right: -6,
          background:'#0F1A2E', color:'#FFF',
          fontSize: 9.5, fontWeight: 700,
          padding: '2px 5px', borderRadius: 4,
          border: '1.5px solid #1E2F4D',
        }}>×{b.count}</div>
      </div>
      <div style={{ fontSize: 9, color:'#FFF', fontWeight: 600, textAlign:'center', lineHeight: 1.1 }}>{b.label}</div>
    </div>
  );
}

function ProfileBefore() {
  return (
    <div style={{
      width: 360, padding: 16,
      background: '#0F1A2E', color:'#FFF',
      fontFamily: 'Archivo, system-ui, sans-serif',
      borderRadius: 0,
    }}>
      {/* Header reduced */}
      <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 12 }}>
        <div style={{
          width: 14, height: 14, borderRadius:'50%',
          background:'#F4A373', display:'flex', alignItems:'center', justifyContent:'center',
        }}>
          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#0F1A2E" strokeWidth="3"><path d="M5 12l5 5L20 7" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <div style={{ fontSize: 16, fontWeight: 700 }}>Scott_D</div>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2"><path d="M12 20h9 M16.5 3.5 a2.12 2.12 0 0 1 3 3 L7 19 l-4 1 1-4 z" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </div>

      {/* Fiabilité (collapsed mock) */}
      <div style={{
        background:'#1E2F4D', borderRadius: 10, padding: 12,
        display:'flex', alignItems:'center', gap: 12, marginBottom: 12,
      }}>
        <div style={{
          width: 60, height: 60, borderRadius:'50%',
          background:'linear-gradient(180deg, #4B7CB8 0%, #1E2F4D 100%)',
          flexShrink: 0,
        }}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 9.5, color:'#8E97A6', textTransform:'uppercase', letterSpacing:'0.12em' }}>Fiabilité</div>
          <div style={{ fontSize: 22, fontWeight: 800, color:'#7EC8A3', lineHeight: 1.1 }}>Bonne</div>
        </div>
        <div style={{ display:'flex', gap: 14 }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize: 16, fontWeight: 800 }}>69</div>
            <div style={{ fontSize: 8, color:'#7EC8A3', textTransform:'uppercase', letterSpacing:'0.1em' }}>Term.</div>
          </div>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize: 16, fontWeight: 800 }}>60</div>
            <div style={{ fontSize: 8, color:'#F26B2E', textTransform:'uppercase', letterSpacing:'0.1em' }}>Créées</div>
          </div>
        </div>
      </div>

      {/* Badges block */}
      <div style={{ background:'#1E2F4D', borderRadius: 10, padding: 14 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing:'0.14em', textTransform:'uppercase', marginBottom: 12, paddingBottom: 8, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          Badges · 10
        </div>

        <div style={{ fontSize: 9.5, color:'#8E97A6', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom: 10, display:'flex', alignItems:'center', gap: 4 }}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="9" cy="7" r="4"/><path d="M17 11l2 2 4-4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/></svg>
          Décernés par les membres
        </div>
        <div style={{ display:'flex', gap: 6, marginBottom: 14 }}>
          {BEFORE_BADGES_COMMU.map((b, i) => <BeforeBadge key={i} b={b}/>)}
        </div>

        <div style={{ fontSize: 9.5, color:'#8E97A6', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom: 10, display:'flex', alignItems:'center', gap: 4 }}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2L14 8l6 1-4.5 4 1 6L12 16l-4.5 3 1-6L4 9l6-1z" strokeLinejoin="round"/></svg>
          Décernés par Junto
        </div>
        <div style={{ display:'flex', gap: 6, flexWrap:'wrap' }}>
          {BEFORE_BADGES_JUNTO.map((b, i) => <BeforeBadge key={i} b={b}/>)}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// AFTER — single row, no number on badge, popover for details
// ============================================================
function ProfileAfter({ variant = 'A', popoverStyle = 'rich', highlightId = null }) {
  const Badge = variant === 'A' ? BadgeA : variant === 'B' ? BadgeB : BadgeC;
  const Popover = popoverStyle === 'rich' ? BadgePopoverRich : BadgePopoverCompact;
  // Sort: peer first (most valuable), then auto, then by count desc, negative pinned at end
  const sorted = [...SAMPLE_BADGES].sort((a, b) => {
    if (a.negative !== b.negative) return a.negative ? 1 : -1;
    if (a.kind !== b.kind) return a.kind === 'peer' ? -1 : 1;
    return b.count - a.count;
  });
  // Show 6 in main row, "Voir tout" at end with overflow count
  const VISIBLE = 6;
  const visible = sorted.slice(0, VISIBLE);
  const overflow = sorted.length - VISIBLE;
  const highlighted = visible.find(b => b.id === highlightId);

  return (
    <div style={{
      width: 360, padding: 16,
      background: '#0F1A2E', color:'#FFF',
      fontFamily: 'Archivo, system-ui, sans-serif',
    }}>
      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 12 }}>
        <div style={{
          width: 14, height: 14, borderRadius:'50%',
          background:'#F4A373', display:'flex', alignItems:'center', justifyContent:'center',
        }}>
          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#0F1A2E" strokeWidth="3"><path d="M5 12l5 5L20 7" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <div style={{ fontSize: 16, fontWeight: 700 }}>Scott_D</div>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2"><path d="M12 20h9 M16.5 3.5 a2.12 2.12 0 0 1 3 3 L7 19 l-4 1 1-4 z" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </div>

      {/* Fiabilité */}
      <div style={{
        background:'#1E2F4D', borderRadius: 10, padding: 12,
        display:'flex', alignItems:'center', gap: 12, marginBottom: 12,
      }}>
        <div style={{
          width: 60, height: 60, borderRadius:'50%',
          background:'linear-gradient(180deg, #4B7CB8 0%, #1E2F4D 100%)',
          flexShrink: 0,
        }}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 9.5, color:'#8E97A6', textTransform:'uppercase', letterSpacing:'0.12em' }}>Fiabilité</div>
          <div style={{ fontSize: 22, fontWeight: 800, color:'#7EC8A3', lineHeight: 1.1 }}>Bonne</div>
        </div>
        <div style={{ display:'flex', gap: 14 }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize: 16, fontWeight: 800 }}>69</div>
            <div style={{ fontSize: 8, color:'#7EC8A3', textTransform:'uppercase', letterSpacing:'0.1em' }}>Term.</div>
          </div>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize: 16, fontWeight: 800 }}>60</div>
            <div style={{ fontSize: 8, color:'#F26B2E', textTransform:'uppercase', letterSpacing:'0.1em' }}>Créées</div>
          </div>
        </div>
      </div>

      {/* Badges block — single row */}
      <div style={{ background:'#1E2F4D', borderRadius: 10, padding: 14 }}>
        <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 12, paddingBottom: 8, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing:'0.14em', textTransform:'uppercase' }}>
            Badges · {sorted.length}
          </div>
          {/* Tier legend */}
          <div style={{ display:'flex', alignItems:'center', gap: 6 }}>
            {['bronze', 'silver', 'gold'].map(t => (
              <div key={t} style={{
                width: 7, height: 7, borderRadius:'50%',
                background: TIER[t].fill,
                border: `1px solid ${TIER[t].ring}`,
              }}/>
            ))}
          </div>
        </div>

        {/* Single horizontal row — badge + label below */}
        <div style={{ display:'flex', alignItems:'flex-start', gap: 6, position:'relative' }}>
          {visible.map(b => (
            <div key={b.id} style={{
              position: 'relative',
              display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
              width: 50,
            }}>
              <Badge b={b} size={40}/>
              <div style={{
                fontSize: 9, color:'#FFF', fontWeight: 600,
                textAlign:'center', lineHeight: 1.15,
                width: 50, overflow:'hidden',
              }}>{b.label}</div>
              {highlightId === b.id && <Popover b={b}/>}
            </div>
          ))}
          {overflow > 0 && (
            <div style={{
              display:'flex', flexDirection:'column', alignItems:'center', gap: 4, width: 50,
            }}>
              <button style={{
                all:'unset', cursor:'pointer',
                width: 40, height: 40, borderRadius:'50%',
                border: '1.5px dashed #5C6E89',
                background: 'transparent',
                color:'#B8C0CC',
                fontSize: 11, fontWeight: 700,
                display:'flex', alignItems:'center', justifyContent:'center',
                flexShrink: 0,
              }}>+{overflow}</button>
              <div style={{ fontSize: 9, color:'#8E97A6', fontWeight: 600 }}>Voir tout</div>
            </div>
          )}
        </div>

        <div style={{ marginTop: 10, fontSize: 10.5, color:'#8E97A6' }}>
          Touche un badge pour les détails
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  ProfileBefore, ProfileAfter,
  BEFORE_BADGES_COMMU, BEFORE_BADGES_JUNTO,
});
