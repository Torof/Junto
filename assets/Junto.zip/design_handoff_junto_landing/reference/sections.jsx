/* Sections: piliers, comment ça marche (map), sorties, screenshots, sports, CTA, footer */

function SectionLabel({ children, color }) {
  return (
    <div className="mono" style={{
      fontSize: 12, fontWeight: 500, color: color || ORANGE,
      letterSpacing: '0.2em', textTransform: 'uppercase',
      display: 'inline-flex', alignItems: 'center', gap: 12, marginBottom: 20,
    }}>
      <span style={{ width: 20, height: 1, background: color || ORANGE, opacity: 0.8 }}/>
      {children}
    </div>
  );
}

function Pillars() {
  const items = [
    {
      kicker: 'Trouve',
      title: 'Une carte vivante des sorties autour de toi.',
      body: 'Filtre par sport, date, niveau. Vois en un coup d\'œil qui part où, quand.',
      art: 'map',
    },
    {
      kicker: 'Crée',
      title: 'Lance ta propre sortie en 30 secondes.',
      body: 'Fixe le RDV, le matos, le niveau. Ta sortie apparaît sur la carte, les autres rejoignent.',
      art: 'create',
    },
    {
      kicker: 'Organise',
      title: 'Covoiturage, chat, matos — tout au même endroit.',
      body: 'Plus de groupes WhatsApp à 40. Les infos de la sortie vivent dans la sortie.',
      art: 'organize',
    },
  ];
  return (
    <section style={{
      padding: '140px 40px',
      background: 'var(--cream-soft)',
      position: 'relative', overflow: 'hidden',
    }}>
      <TopoLines opacity={0.05} color={NAVY} count={10}/>
      <div style={{ maxWidth: 1180, margin: '0 auto', position: 'relative' }}>
        <div style={{ marginBottom: 80, maxWidth: 820 }}>
          <SectionLabel>Ce que tu fais avec Junto</SectionLabel>
          <h2 className="display" style={{
            fontSize: 64, lineHeight: 0.98, margin: 0,
            fontWeight: 800, letterSpacing: '-0.035em', color: NAVY,
            textWrap: 'balance',
          }}>
            Trouver une sortie. En créer une. <span style={{ color: ORANGE }}>S'organiser.</span>
          </h2>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          {items.map((it, i) => (
            <div key={i} style={{
              background: '#FFF',
              border: '1px solid var(--line)',
              borderRadius: 24,
              padding: '48px 56px',
              display: 'grid',
              gridTemplateColumns: '1fr 320px',
              gap: 48,
              alignItems: 'center',
            }}>
              <div>
                <div style={{
                  display: 'inline-flex', alignItems: 'baseline', gap: 14,
                  marginBottom: 20,
                }}>
                  <span className="display" style={{
                    fontSize: 56, fontWeight: 800,
                    letterSpacing: '-0.04em', color: ORANGE,
                    lineHeight: 0.9,
                  }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span className="display" style={{
                    fontSize: 28, fontWeight: 800,
                    letterSpacing: '-0.02em', color: NAVY,
                  }}>
                    {it.kicker}
                  </span>
                </div>
                <h3 className="display" style={{
                  fontSize: 36, margin: '0 0 16px', fontWeight: 800,
                  letterSpacing: '-0.025em', color: NAVY, lineHeight: 1.05,
                  textWrap: 'balance',
                }}>
                  {it.title}
                </h3>
                <p style={{ fontSize: 17, lineHeight: 1.55, margin: 0, color: 'var(--muted)', maxWidth: 520 }}>
                  {it.body}
                </p>
              </div>

              <div style={{
                height: 220,
                background: it.art === 'map' ? '#EFE4CE' : it.art === 'create' ? ORANGE : '#F4EBD9',
                borderRadius: 16,
                position: 'relative',
                overflow: 'hidden',
              }}>
                <PillarArt kind={it.art}/>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function PillarArt({ kind }) {
  if (kind === 'map') {
    // Realistic-ish map: landmasses, water, roads, pins
    return (
      <svg viewBox="0 0 320 220" style={{ width: '100%', height: '100%' }} preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="pMapGrid" width="32" height="32" patternUnits="userSpaceOnUse">
            <path d="M 32 0 L 0 0 0 32" fill="none" stroke="#FFF" strokeWidth="0.4" opacity="0.3"/>
          </pattern>
        </defs>
        {/* Land base (cream) */}
        <rect width="320" height="220" fill="#EFE4CE"/>
        {/* Forests / green patches */}
        <path d="M -10 -10 Q 60 20 90 60 Q 70 110 120 140 Q 90 180 40 200 L -10 220 Z" fill="#C9D9B8" opacity="0.8"/>
        <path d="M 220 -10 Q 260 30 250 70 Q 290 100 310 80 L 330 -10 Z" fill="#C9D9B8" opacity="0.8"/>
        <path d="M 180 180 Q 230 170 260 200 L 280 230 L 180 230 Z" fill="#C9D9B8" opacity="0.8"/>
        {/* Water / river */}
        <path d="M -10 110 Q 80 90 140 120 Q 200 150 320 130 L 320 150 Q 200 170 140 140 Q 80 110 -10 130 Z" fill="#B8D1E3"/>
        <path d="M -10 110 Q 80 90 140 120 Q 200 150 320 130" fill="none" stroke="#8FB3CC" strokeWidth="0.6" opacity="0.6"/>
        {/* Lake */}
        <ellipse cx="70" cy="180" rx="24" ry="14" fill="#B8D1E3"/>
        {/* Roads */}
        <g fill="none" strokeLinecap="round">
          <path d="M 0 70 Q 100 50 180 80 T 320 60" stroke="#FFF" strokeWidth="3"/>
          <path d="M 0 70 Q 100 50 180 80 T 320 60" stroke="#E8A66B" strokeWidth="1.5" strokeDasharray="0"/>
          <path d="M 40 0 Q 80 80 150 110 Q 200 140 240 220" stroke="#FFF" strokeWidth="2.5"/>
          <path d="M 40 0 Q 80 80 150 110 Q 200 140 240 220" stroke="#D9CDB4" strokeWidth="1"/>
        </g>
        {/* Grid overlay */}
        <rect width="320" height="220" fill="url(#pMapGrid)" opacity="0.4"/>
        {/* Pins */}
        {[[70, 75, ORANGE, '🧗'], [210, 55, NAVY, '🥾'], [250, 130, ORANGE, '🪂'], [140, 170, NAVY, '🚵']].map(([x,y,c,e], i) => (
          <g key={i} transform={`translate(${x-14}, ${y-32})`}>
            <ellipse cx="14" cy="34" rx="8" ry="2" fill="#000" opacity="0.18"/>
            <path d="M 14 32 L 8 22 Q 0 22 0 12 Q 0 0 14 0 Q 28 0 28 12 Q 28 22 20 22 Z" fill={c} stroke="#FFF" strokeWidth="1.5"/>
            <text x="14" y="16" textAnchor="middle" fontSize="12" dominantBaseline="middle">{e}</text>
          </g>
        ))}
        {/* "You are here" marker */}
        <g transform="translate(40, 140)">
          <circle r="14" fill={ORANGE} opacity="0.2"/>
          <circle r="7" fill={ORANGE} opacity="0.35"/>
          <circle r="4" fill={ORANGE} stroke="#FFF" strokeWidth="1.5"/>
        </g>
      </svg>
    );
  }
  if (kind === 'create') {
    // A mini "create" form floating on orange bg
    return (
      <div style={{ position: 'absolute', inset: 0, padding: 20, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{
          background: '#FFF', borderRadius: 14, padding: 18, width: 260,
          boxShadow: '0 20px 40px -10px rgba(0,0,0,0.3)',
        }}>
          <div className="mono" style={{ fontSize: 10, color: ORANGE, letterSpacing: '0.12em', marginBottom: 8 }}>
            NOUVELLE SORTIE
          </div>
          <div className="display" style={{ fontSize: 18, fontWeight: 800, color: NAVY, letterSpacing: '-0.02em', marginBottom: 10 }}>
            Escalade au Verdon
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12, color: 'var(--muted)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 14, height: 14, borderRadius: 3, background: '#F4EBD9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9 }}>📅</span>
              Dim. 27 avr · 8h30
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 14, height: 14, borderRadius: 3, background: '#F4EBD9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9 }}>👥</span>
              4 places disponibles
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 14, height: 14, borderRadius: 3, background: '#F4EBD9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9 }}>🎚</span>
              Niveau 5b — 6b
            </div>
          </div>
          <div style={{
            marginTop: 12, padding: '8px 12px', borderRadius: 8,
            background: NAVY, color: '#FFF', fontSize: 12, fontWeight: 700, textAlign: 'center',
          }}>
            Publier la sortie
          </div>
        </div>
      </div>
    );
  }
  // organize — messages mock
  return (
    <div style={{ position: 'absolute', inset: 0, padding: 20, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 10 }}>
      {[
        { who: 'Léa', msg: 'Je prends 3 places en voiture 🚗', mine: false },
        { who: 'Moi', msg: 'Parfait, je viens avec toi', mine: true },
        { who: 'Tom', msg: 'J\'ai un casque en rab', mine: false },
      ].map((m, i) => (
        <div key={i} style={{
          alignSelf: m.mine ? 'flex-end' : 'flex-start',
          maxWidth: '80%',
          background: m.mine ? NAVY : '#FFF',
          color: m.mine ? '#FFF' : NAVY,
          padding: '10px 14px',
          borderRadius: m.mine ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
          fontSize: 13, lineHeight: 1.35,
          boxShadow: '0 4px 10px -2px rgba(0,0,0,0.08)',
        }}>
          {!m.mine && <div style={{ fontSize: 10, fontWeight: 700, color: ORANGE, marginBottom: 2, letterSpacing: '0.05em' }}>{m.who.toUpperCase()}</div>}
          {m.msg}
        </div>
      ))}
    </div>
  );
}

function HowItWorks() {
  // Map-based: a topo-style map with 3 pins along a path
  const steps = [
    { n: '01', title: 'Trouve', body: 'Ouvre la carte.' },
    { n: '02', title: 'Rejoins', body: 'Un tap, tu es dedans.' },
    { n: '03', title: 'Pars', body: 'Chat, transport, go.' },
  ];
  return (
    <section id="comment" style={{
      padding: '140px 40px',
      background: NAVY,
      color: '#FFF',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ maxWidth: 1180, margin: '0 auto', position: 'relative' }}>
        <div style={{ marginBottom: 60, maxWidth: 720 }}>
          <SectionLabel color={ORANGE_SOFT}>Comment ça marche</SectionLabel>
          <h2 className="display" style={{
            fontSize: 64, lineHeight: 0.98, margin: 0,
            fontWeight: 800, letterSpacing: '-0.035em',
            textWrap: 'balance',
          }}>
            Trois arrêts<br/>
            <span style={{ color: ORANGE_SOFT }}>sur ton itinéraire.</span>
          </h2>
        </div>

        {/* The map */}
        <div style={{
          position: 'relative',
          borderRadius: 24,
          overflow: 'hidden',
          background: '#132238',
          border: '1px solid rgba(255,255,255,0.08)',
          aspectRatio: '16 / 8',
        }}>
          <svg viewBox="0 0 1400 700" preserveAspectRatio="xMidYMid slice" style={{ width: '100%', height: '100%', display: 'block' }}>
            <defs>
              <pattern id="gridPattern" width="50" height="50" patternUnits="userSpaceOnUse">
                <path d="M 50 0 L 0 0 0 50" fill="none" stroke={CREAM} strokeWidth="0.5" opacity="0.08"/>
              </pattern>
            </defs>

            {/* Grid */}
            <rect width="1400" height="700" fill="url(#gridPattern)"/>

            {/* Topo contours */}
            <g stroke={ORANGE_SOFT} strokeWidth="1" fill="none" opacity="0.25">
              <path d="M 200 600 Q 400 500 600 550 Q 800 600 1000 480 Q 1200 380 1300 420"/>
              <path d="M 200 540 Q 400 440 600 490 Q 800 540 1000 420 Q 1200 320 1300 360"/>
              <path d="M 200 480 Q 400 380 600 430 Q 800 480 1000 360 Q 1200 260 1300 300"/>
              <path d="M 250 420 Q 420 340 600 370 Q 800 420 1000 300 Q 1180 200 1260 240"/>
              <path d="M 320 360 Q 460 300 600 310 Q 800 360 1000 240 Q 1160 160 1200 180"/>
            </g>

            {/* Secondary topo (further mountains) */}
            <g stroke={CREAM} strokeWidth="0.8" fill="none" opacity="0.15">
              <path d="M 60 200 Q 180 140 280 180 Q 380 210 500 170"/>
              <path d="M 60 160 Q 180 100 280 140 Q 380 170 500 130"/>
              <path d="M 900 140 Q 1040 80 1180 120 Q 1290 150 1370 110"/>
            </g>

            {/* Main path connecting the 3 pins */}
            <path
              d="M 252 504 C 420 470, 540 420, 700 350 C 860 280, 1000 220, 1148 196"
              fill="none"
              stroke={ORANGE}
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="2 10"
            />

            {/* Scale bar and north arrow */}
            <g transform="translate(80, 60)">
              <path d="M 0 -22 L 8 10 L 0 2 L -8 10 Z" fill={CREAM} opacity="0.6"/>
              <text x="0" y="26" textAnchor="middle" fontSize="11" fill={CREAM} opacity="0.6" fontFamily="JetBrains Mono, monospace" letterSpacing="0.1em">N</text>
            </g>
            <g transform="translate(1200, 640)">
              <rect x="0" y="0" width="60" height="4" fill={CREAM} opacity="0.4"/>
              <rect x="60" y="0" width="60" height="4" fill="none" stroke={CREAM} strokeWidth="1" opacity="0.4"/>
              <text x="60" y="22" textAnchor="middle" fontSize="10" fill={CREAM} opacity="0.5" fontFamily="JetBrains Mono, monospace" letterSpacing="0.08em">1 KM</text>
            </g>
          </svg>

          {/* Step pins positioned absolute */}
          {[
            { x: '18%', y: '72%', step: steps[0] },
            { x: '50%', y: '50%', step: steps[1] },
            { x: '82%', y: '28%', step: steps[2] },
          ].map((p, i) => (
            <div key={i} style={{
              position: 'absolute', left: p.x, top: p.y,
              transform: 'translate(-50%, -100%)',
              display: 'flex', flexDirection: 'column', alignItems: 'center',
            }}>
              {/* Card above the pin */}
              <div style={{
                background: '#FFF', color: NAVY,
                padding: '14px 18px', borderRadius: 12,
                marginBottom: 14,
                minWidth: 180, textAlign: 'left',
                boxShadow: '0 20px 40px -10px rgba(0,0,0,0.4)',
              }}>
                <div className="mono" style={{ fontSize: 10, color: ORANGE, letterSpacing: '0.15em', marginBottom: 4 }}>
                  ÉTAPE {p.step.n}
                </div>
                <div className="display" style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em', lineHeight: 1, marginBottom: 4 }}>
                  {p.step.title}
                </div>
                <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.4 }}>
                  {p.step.body}
                </div>
              </div>
              {/* Pin */}
              <svg width="44" height="56" viewBox="0 0 44 56">
                <path
                  d="M 22 54 L 13 40 Q 2 40 2 22 Q 2 2 22 2 Q 42 2 42 22 Q 42 40 31 40 Z"
                  fill={ORANGE} stroke={NAVY_DEEP} strokeWidth="2.5"
                />
                <circle cx="22" cy="21" r="9" fill="#FFF"/>
                <text x="22" y="25" textAnchor="middle" fontSize="11" fontWeight="800" fill={NAVY} fontFamily="Archivo, sans-serif">{i + 1}</text>
              </svg>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function UpcomingTrips() {
  const trips = [
    { sport: 'Escalade', emoji: '🧗', location: 'Calanques, Marseille', date: 'Dim. 27 avr', time: '9h', level: 'Tous niveaux', detail: '6a → 7a', participants: 4, max: 6, accent: '#F26B2E' },
    { sport: 'Parapente', emoji: '🪂', location: 'Col de la Forclaz, Annecy', date: 'Sam. 3 mai', time: '7h30', level: 'Pilote autonome', detail: 'Déniv. 900 m', participants: 3, max: 5, accent: '#4B7CB8' },
    { sport: 'Trail', emoji: '🏃', location: 'Belledonne, Grenoble', date: 'Dim. 4 mai', time: '8h', level: 'Confirmé', detail: '25 km · D+ 1 400 m', participants: 6, max: 10, accent: '#7EC8A3' },
    { sport: 'Ski de rando', emoji: '🎿', location: 'Vallée Blanche, Chamonix', date: 'Sam. 10 mai', time: '5h30', level: 'Confirmé', detail: 'D+ 1 200 m', participants: 2, max: 4, accent: '#F4A373' },
  ];
  return (
    <section id="sorties" style={{
      padding: '140px 40px',
      background: 'var(--cream-soft)',
      position: 'relative', overflow: 'hidden',
    }}>
      <TopoLines opacity={0.04} color={NAVY} count={10}/>
      <div style={{ maxWidth: 1180, margin: '0 auto', position: 'relative' }}>
        <div style={{ marginBottom: 64, maxWidth: 720 }}>
          <SectionLabel>Cette semaine</SectionLabel>
          <h2 className="display" style={{
            fontSize: 64, lineHeight: 0.98, margin: 0,
            fontWeight: 800, letterSpacing: '-0.035em', color: NAVY,
            textWrap: 'balance',
          }}>
            Des sorties, <span style={{ color: ORANGE }}>en vrai.</span>
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
          {trips.map((t, i) => (
            <div key={i} style={{
              background: '#FFF', border: '1px solid var(--line)',
              borderRadius: 20, padding: 28,
              display: 'grid', gridTemplateColumns: '64px 1fr auto', gap: 20, alignItems: 'center',
            }}>
              <div style={{
                width: 64, height: 64, borderRadius: 16,
                background: t.accent + '22',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 30,
              }}>{t.emoji}</div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6, flexWrap: 'wrap' }}>
                  <span className="mono" style={{ fontSize: 11, fontWeight: 600, color: t.accent, textTransform: 'uppercase', letterSpacing: '0.12em' }}>{t.sport}</span>
                  <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--muted)' }}/>
                  <span style={{ fontSize: 13, color: 'var(--muted)' }}>{t.level}</span>
                  <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--muted)' }}/>
                  <span style={{ fontSize: 13, color: 'var(--muted)' }}>{t.detail}</span>
                </div>
                <h3 className="display" style={{ fontSize: 22, margin: '0 0 6px', fontWeight: 800, color: NAVY, letterSpacing: '-0.02em' }}>
                  {t.location}
                </h3>
                <div style={{ fontSize: 13, color: 'var(--muted)', display: 'flex', gap: 10 }}>
                  <span>{t.date}</span>
                  <span>·</span>
                  <span>{t.time}</span>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="display" style={{ fontSize: 26, fontWeight: 800, color: NAVY, letterSpacing: '-0.02em' }}>{t.participants}/{t.max}</div>
                <div className="mono" style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Partants</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Screenshots() {
  const screens = [
    { src: 'screen_map.jpeg', title: 'La carte' },
    { src: 'screen_popup.jpeg', title: 'Un aperçu' },
    { src: 'screen_activity.jpeg', title: 'Le détail' },
    { src: 'screen_profile.jpeg', title: 'Le profil' },
  ];
  return (
    <section style={{
      padding: '140px 40px',
      background: NAVY_DEEP,
      color: '#FFF',
      overflow: 'hidden',
      position: 'relative',
    }}>
      <TopoLines opacity={0.04} color={CREAM} count={8}/>
      <div style={{ maxWidth: 1280, margin: '0 auto', position: 'relative' }}>
        <div style={{ marginBottom: 80, maxWidth: 720 }}>
          <SectionLabel color={ORANGE_SOFT}>L'app</SectionLabel>
          <h2 className="display" style={{
            fontSize: 64, lineHeight: 0.98, margin: 0,
            fontWeight: 800, letterSpacing: '-0.035em',
            textWrap: 'balance',
          }}>
            Pensée pour le <span style={{ color: ORANGE_SOFT }}>terrain.</span>
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 28 }}>
          {screens.map((s, i) => (
            <div key={i}>
              <div style={{
                borderRadius: 32,
                padding: 8,
                background: 'linear-gradient(180deg, #2A3E5F 0%, #182238 100%)',
                boxShadow: '0 40px 60px -20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.08)',
                transform: i % 2 === 0 ? 'translateY(0)' : 'translateY(28px)',
              }}>
                <div style={{
                  borderRadius: 26, overflow: 'hidden',
                  aspectRatio: '1080 / 2020',
                  background: '#000',
                }}>
                  <img src={s.src} style={{ width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'top', display: 'block' }}/>
                </div>
              </div>
              <div style={{ padding: '28px 8px 0', textAlign: 'center' }}>
                <div className="mono" style={{ fontSize: 10, color: ORANGE_SOFT, letterSpacing: '0.15em', marginBottom: 6 }}>
                  0{i + 1}
                </div>
                <div className="display" style={{ fontSize: 20, fontWeight: 800, letterSpacing: '-0.02em' }}>
                  {s.title}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Sports() {
  const categories = [
    {
      name: 'Montagne',
      accent: '#F26B2E',
      sports: ['Randonnée', 'Escalade', 'Ski de rando', 'Trail', 'Alpinisme', 'Via ferrata', 'Cascade de glace', 'Canyoning', 'Slackline'],
    },
    {
      name: 'Eau',
      accent: '#4B7CB8',
      sports: ['Kayak', 'Surf', 'Voile', 'Stand-up Paddle', 'Rafting', 'Plongée', 'Natation'],
    },
    {
      name: 'Neige',
      accent: '#9DB7D4',
      sports: ['Ski', 'Snowboard', 'Ski de fond'],
    },
    {
      name: 'Air',
      accent: '#F4A373',
      sports: ['Parapente', 'Parachutisme'],
    },
    {
      name: 'Vélo',
      accent: '#7EC8A3',
      sports: ['Vélo', 'VTT'],
    },
    {
      name: 'Terrain',
      accent: '#D4B46A',
      sports: ['Course à pied', 'Football', 'Tennis', 'Volleyball', 'Badminton', 'Équitation', 'Skateboard', 'Triathlon', 'CrossFit', 'Pêche en roche'],
    },
  ];

  const total = categories.reduce((n, c) => n + c.sports.length, 0);

  return (
    <section style={{
      padding: '140px 40px',
      background: 'var(--cream)',
      position: 'relative', overflow: 'hidden',
    }}>
      <TopoLines opacity={0.05} color={NAVY} count={10}/>
      <div style={{ maxWidth: 1180, margin: '0 auto', position: 'relative' }}>
        <div style={{ marginBottom: 72, maxWidth: 820 }}>
          <SectionLabel>Catalogue</SectionLabel>
          <h2 className="display" style={{
            fontSize: 64, lineHeight: 0.98, margin: 0,
            fontWeight: 800, letterSpacing: '-0.035em', color: NAVY,
            textWrap: 'balance',
          }}>
            <span style={{ color: ORANGE }}>{total} sports</span> — et ça grandit.
          </h2>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 0, borderTop: '1px solid rgba(30,47,77,0.12)' }}>
          {categories.map((cat, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '200px 1fr',
              gap: 40,
              padding: '32px 0',
              borderBottom: '1px solid rgba(30,47,77,0.12)',
              alignItems: 'baseline',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{
                  width: 10, height: 10, borderRadius: '50%',
                  background: cat.accent, flexShrink: 0,
                }}/>
                <span className="display" style={{
                  fontSize: 22, fontWeight: 800, color: NAVY,
                  letterSpacing: '-0.02em',
                }}>{cat.name}</span>
                <span className="mono" style={{ fontSize: 11, color: 'var(--muted)', letterSpacing: '0.1em' }}>
                  {String(cat.sports.length).padStart(2, '0')}
                </span>
              </div>

              <div style={{
                display: 'flex', flexWrap: 'wrap', gap: '12px 20px',
                fontSize: 17, fontWeight: 500, color: NAVY,
                lineHeight: 1.4,
              }}>
                {cat.sports.map((s, j) => (
                  <span key={j} style={{ display: 'inline-flex', alignItems: 'center' }}>
                    {s}
                    {j < cat.sports.length - 1 && (
                      <span style={{ marginLeft: 20, color: 'rgba(30,47,77,0.2)' }}>·</span>
                    )}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 32, fontSize: 14, color: 'var(--muted)' }}>
          Un sport manque ? <a href="mailto:contact@getjunto.app" style={{ color: ORANGE, textDecoration: 'underline' }}>Dis-le nous</a>.
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section id="beta" style={{
      padding: '140px 40px',
      background: NAVY,
      color: '#FFF',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(circle at 80% 20%, ${ORANGE}22 0%, transparent 50%),
                     radial-gradient(circle at 20% 80%, ${SKY}22 0%, transparent 50%)`,
      }}/>
      <TopoLines opacity={0.06} color={CREAM} count={10}/>

      <div style={{ maxWidth: 960, margin: '0 auto', position: 'relative', textAlign: 'center' }}>
        <SectionLabel color={ORANGE_SOFT}>Rejoins la bêta</SectionLabel>
        <h2 className="display" style={{
          fontSize: 84, lineHeight: 0.96, margin: 0,
          fontWeight: 800, letterSpacing: '-0.04em',
          textWrap: 'balance',
        }}>
          Ta prochaine sortie<br/>
          <span style={{ color: ORANGE_SOFT }}>t'attend déjà.</span>
        </h2>

        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 40, flexWrap: 'wrap',
          marginTop: 56,
        }}>
          <div style={{ textAlign: 'right' }}>
            <a href="#" style={{
              display: 'inline-flex', alignItems: 'center', gap: 12,
              background: ORANGE, color: '#FFF',
              padding: '18px 28px', borderRadius: 12,
              fontSize: 16, fontWeight: 700, textDecoration: 'none',
            }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.523 15.34a4 4 0 1 1-7.846-1.68L12 10l5.523 5.34zm-11.046 0L12 10l2.323 3.66a4 4 0 1 1-7.846 1.68zM12 2L8 6h8l-4-4z"/>
              </svg>
              Télécharger l'APK
            </a>
            <div className="mono" style={{ fontSize: 10, opacity: 0.4, letterSpacing: '0.1em', marginTop: 12 }}>
              ANDROID 9+ · ~24 MO
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div className="mono" style={{ fontSize: 11, opacity: 0.5, letterSpacing: '0.15em', writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
              OU SCANNE →
            </div>
            <div style={{
              width: 140, height: 140, borderRadius: 16,
              background: '#FFF', padding: 12,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%' }}>
                <rect width="100" height="100" fill="#FFF"/>
                <g fill={NAVY}>
                  {[[6,6,20,20],[74,6,20,20],[6,74,20,20]].map((r,i)=>(
                    <g key={i}><rect x={r[0]} y={r[1]} width={r[2]} height={r[3]}/><rect x={r[0]+4} y={r[1]+4} width={r[2]-8} height={r[3]-8} fill="#FFF"/><rect x={r[0]+8} y={r[1]+8} width={r[2]-16} height={r[3]-16}/></g>
                  ))}
                  {Array.from({length: 14}).map((_,y)=>Array.from({length:14}).map((_,x)=>{
                    const cx = 30 + x*4, cy = 30 + y*4;
                    if ((x*7 + y*3 + x*y) % 3 === 0) return <rect key={`${x}${y}`} x={cx} y={cy} width="3" height="3"/>;
                    return null;
                  }))}
                </g>
              </svg>
            </div>
          </div>
        </div>

        <div style={{ fontSize: 13, opacity: 0.55, marginTop: 48 }}>
          iOS bientôt — <a href="mailto:contact@getjunto.app" style={{ color: ORANGE_SOFT, textDecoration: 'underline' }}>demande TestFlight</a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer style={{
      padding: '56px 40px 40px',
      background: NAVY_DEEP, color: '#FFF',
      borderTop: '1px solid rgba(255,255,255,0.06)',
    }}>
      <div style={{
        maxWidth: 1180, margin: '0 auto',
        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 40, flexWrap: 'wrap',
      }}>
        <div style={{ maxWidth: 320 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <JuntoMark size={32}/>
            <span className="display" style={{ fontSize: 20, fontWeight: 800, letterSpacing: '-0.02em' }}>Junto</span>
          </div>
          <a href="mailto:contact@getjunto.app" style={{
            fontSize: 14, color: ORANGE_SOFT, textDecoration: 'none',
            borderBottom: `1px solid ${ORANGE_SOFT}44`,
            paddingBottom: 2,
          }}>contact@getjunto.app</a>
        </div>

        <div style={{ display: 'flex', gap: 48, fontSize: 14 }}>
          <div>
            <div className="mono" style={{ fontSize: 11, opacity: 0.4, letterSpacing: '0.15em', marginBottom: 14 }}>PRODUIT</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <a href="#comment" style={{ opacity: 0.8, textDecoration: 'none' }}>Comment ça marche</a>
              <a href="#sorties" style={{ opacity: 0.8, textDecoration: 'none' }}>Sorties</a>
              <a href="#beta" style={{ opacity: 0.8, textDecoration: 'none' }}>Bêta</a>
            </div>
          </div>
          <div>
            <div className="mono" style={{ fontSize: 11, opacity: 0.4, letterSpacing: '0.15em', marginBottom: 14 }}>LÉGAL</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <a href="#" style={{ opacity: 0.8, textDecoration: 'none' }}>Confidentialité</a>
              <a href="#" style={{ opacity: 0.8, textDecoration: 'none' }}>Conditions</a>
            </div>
          </div>
        </div>
      </div>

      <div style={{
        maxWidth: 1180, margin: '48px auto 0',
        borderTop: '1px solid rgba(255,255,255,0.08)',
        paddingTop: 24,
        display: 'flex', justifyContent: 'space-between',
        fontSize: 12, opacity: 0.45,
      }}>
        <div>© Junto 2026</div>
        <div className="mono" style={{ letterSpacing: '0.1em' }}>MADE IN FRANCE 🏔️</div>
      </div>
    </footer>
  );
}

Object.assign(window, { Pillars, HowItWorks, UpcomingTrips, Screenshots, Sports, FinalCTA, Footer });
