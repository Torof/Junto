/* Badge system V2 — tiered (bronze/silver/gold) + negative state
   Tiers based on count of times unlocked:
     0   → unlocked never (locked / outline)
     1-9 → bronze
     10-49 → silver
     50+ → gold
   Negative badges → red/black tier (always shown distinctly)
*/

// ===== TIER PALETTES =====
// Each tier = { ring, fill, fillSoft, glow, accent } for a coherent look
const TIER = {
  bronze: {
    ring: '#B87333',         // burnished copper
    fill: 'linear-gradient(160deg, #D4894C 0%, #8C5424 100%)',
    fillSoft: 'rgba(184, 115, 51, 0.18)',
    glow: 'rgba(184, 115, 51, 0.45)',
    label: 'Bronze',
  },
  silver: {
    ring: '#B8C4CF',
    fill: 'linear-gradient(160deg, #DCE3EB 0%, #8B95A1 100%)',
    fillSoft: 'rgba(184, 196, 207, 0.18)',
    glow: 'rgba(184, 196, 207, 0.45)',
    label: 'Argent',
  },
  gold: {
    ring: '#E8B547',
    fill: 'linear-gradient(160deg, #F5CD63 0%, #B8862C 100%)',
    fillSoft: 'rgba(232, 181, 71, 0.20)',
    glow: 'rgba(232, 181, 71, 0.55)',
    label: 'Or',
  },
  negative: {
    ring: '#E5524E',
    fill: 'linear-gradient(160deg, #E5524E 0%, #7A1A1A 100%)',
    fillSoft: 'rgba(229, 82, 78, 0.18)',
    glow: 'rgba(229, 82, 78, 0.45)',
    label: 'Signal',
  },
  locked: {
    ring: '#3A4A66',
    fill: 'transparent',
    fillSoft: 'transparent',
    glow: 'transparent',
    label: 'Verrouillé',
  },
};

const tierFor = (count) => {
  if (count <= 0) return 'locked';
  if (count < 10) return 'bronze';
  if (count < 50) return 'silver';
  return 'gold';
};

// ===== ICONS — matched to typical Junto badge categories =====
const BADGE_ICON = {
  shield:    <path d="M12 2 L3 5 L3 11 C3 17 8 21 12 22 C16 21 21 17 21 11 L21 5 Z" strokeLinejoin="round"/>,
  'shield-check': <><path d="M12 2 L3 5 L3 11 C3 17 8 21 12 22 C16 21 21 17 21 11 L21 5 Z" strokeLinejoin="round"/><path d="M8 12 L11 15 L16 9" strokeLinecap="round" strokeLinejoin="round"/></>,
  star:      <path d="M12 2 L14.5 9 L22 9.5 L16 14.5 L18 22 L12 17.5 L6 22 L8 14.5 L2 9.5 L9.5 9 Z" strokeLinejoin="round"/>,
  smile:     <><circle cx="12" cy="12" r="9.5"/><path d="M8 14 C9.5 16 14.5 16 16 14" strokeLinecap="round"/><circle cx="9" cy="10" r="0.6" fill="currentColor"/><circle cx="15" cy="10" r="0.6" fill="currentColor"/></>,
  clock:     <><circle cx="12" cy="12" r="9.5"/><path d="M12 7 V12 L15.5 14" strokeLinecap="round" strokeLinejoin="round"/></>,
  bolt:      <path d="M13 2 L4 14 L11 14 L10 22 L20 9 L13 9 Z" strokeLinejoin="round"/>,
  flag:      <><path d="M5 22 V3" strokeLinecap="round"/><path d="M5 4 L18 4 L15 9 L18 14 L5 14" strokeLinejoin="round"/></>,
  mountain:  <path d="M3 20 L9 9 L13 15 L16 11 L21 20 Z" strokeLinejoin="round"/>,
  wave:      <path d="M3 14 C5 12 7 16 9 14 C11 12 13 16 15 14 C17 12 19 16 21 14 M3 18 C5 16 7 20 9 18 C11 16 13 20 15 18 C17 16 19 20 21 18" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  paraglide: <><path d="M3 8 C8 4 16 4 21 8" strokeLinecap="round"/><path d="M3 8 L12 14 L21 8" strokeLinejoin="round"/><path d="M12 14 L12 21" strokeLinecap="round"/></>,
  flame:     <path d="M12 2 C12 7 8 8 8 13 C8 17 10 21 12 21 C14 21 16 17 16 13 C16 10 14 9 13 7 C13 5 12 4 12 2 Z" strokeLinejoin="round"/>,
  alert:     <><path d="M12 3 L22 20 L2 20 Z" strokeLinejoin="round"/><path d="M12 10 V14" strokeLinecap="round"/><circle cx="12" cy="17" r="0.6" fill="currentColor"/></>,
  ghost:     <><path d="M5 21 V11 a7 7 0 0 1 14 0 V21 L17 19 L15 21 L13 19 L11 21 L9 19 L7 21 Z" strokeLinejoin="round"/><circle cx="9.5" cy="11" r="0.6" fill="currentColor"/><circle cx="14.5" cy="11" r="0.6" fill="currentColor"/></>,
};

// ===== BADGE DATA =====
// kind: 'peer' (commu) or 'auto' (système)
// count: how many times unlocked
// negative: true → uses red tier regardless of count
const SAMPLE_BADGES = [
  { id:'trust',    label:'De confiance',     icon:'shield-check', kind:'peer', count: 30, desc:"30 personnes t'ont marqué·e comme un partenaire de confiance.", lastAt:'12 mars 2026' },
  { id:'leader',   label:'Super leader',     icon:'star',         kind:'peer', count: 28, desc:"Salué·e comme leader sur 28 sorties.", lastAt:'8 mars 2026' },
  { id:'ambiance', label:'Bonne ambiance',   icon:'smile',        kind:'peer', count: 28, desc:"28 membres t'ont attribué une bonne ambiance.", lastAt:'5 mars 2026' },
  { id:'punctual', label:'Ponctuel',         icon:'clock',        kind:'peer', count: 28, desc:"28 sorties commencées à l'heure annoncée.", lastAt:'2 mars 2026' },
  { id:'regular',  label:'Régulier',         icon:'bolt',         kind:'auto', count: 20, desc:"20 sorties terminées sur les 90 derniers jours." },
  { id:'animator', label:'Animateur',        icon:'flag',         kind:'auto', count: 49, desc:"49 sorties créées et menées." },
  { id:'curious-c',label:'Curieux Escalade', icon:'mountain',     kind:'auto', count: 6,  desc:"6 sorties terminées dans une nouvelle discipline (escalade)." },
  { id:'curious-w',label:'Curieux Canyoning',icon:'wave',         kind:'auto', count: 7,  desc:"7 sorties dans une nouvelle discipline (canyoning)." },
  { id:'mordu',    label:'Mordu Parapente', icon:'paraglide',    kind:'auto', count: 32, desc:"32 sorties parapente terminées." },
  // Negative — peer review options that flag friction
  { id:'noshow',   label:'Désistement',      icon:'ghost',        kind:'peer', count: 2,  negative:true, desc:"Signalé·e 2 fois pour ne pas s'être présenté·e à la sortie." },
];

// ============================================================
// VARIANT A — Round badge, icon centered, tier color = full fill
// ============================================================
function BadgeA({ b, size = 44, onTap }) {
  const tier = b.negative ? 'negative' : tierFor(b.count);
  const t = TIER[tier];
  const isLocked = tier === 'locked';
  return (
    <button onClick={onTap} style={{
      all:'unset', cursor: onTap ? 'pointer' : 'default',
      width: size, height: size, borderRadius:'50%',
      background: isLocked ? 'transparent' : t.fill,
      border: isLocked ? `1.5px dashed ${t.ring}` : `1.5px solid ${t.ring}`,
      boxShadow: isLocked ? 'none' : `0 4px 14px -4px ${t.glow}, inset 0 1px 0 rgba(255,255,255,0.25)`,
      display:'flex', alignItems:'center', justifyContent:'center',
      flexShrink: 0,
    }}>
      <svg width={size*0.5} height={size*0.5} viewBox="0 0 24 24" fill="none"
        stroke={isLocked ? '#5C6E89' : '#FFF'} strokeWidth="2"
        style={{ filter: isLocked ? 'none' : 'drop-shadow(0 1px 1px rgba(0,0,0,0.25))' }}>
        {BADGE_ICON[b.icon]}
      </svg>
    </button>
  );
}

// ============================================================
// VARIANT B — Tier ring around icon (icon stays neutral navy)
// ============================================================
function BadgeB({ b, size = 44, onTap }) {
  const tier = b.negative ? 'negative' : tierFor(b.count);
  const t = TIER[tier];
  const isLocked = tier === 'locked';
  return (
    <button onClick={onTap} style={{
      all:'unset', cursor: onTap ? 'pointer' : 'default',
      width: size, height: size, borderRadius:'50%',
      padding: 2.5,
      background: t.fill,
      boxShadow: isLocked ? 'none' : `0 4px 12px -4px ${t.glow}`,
      flexShrink: 0,
    }}>
      <div style={{
        width:'100%', height:'100%', borderRadius:'50%',
        background: '#1E2F4D',
        display:'flex', alignItems:'center', justifyContent:'center',
      }}>
        <svg width={size*0.46} height={size*0.46} viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2">
          {BADGE_ICON[b.icon]}
        </svg>
      </div>
    </button>
  );
}

// ============================================================
// VARIANT C — Faceted "coin" with tier accent dot
// ============================================================
function BadgeC({ b, size = 44, onTap }) {
  const tier = b.negative ? 'negative' : tierFor(b.count);
  const t = TIER[tier];
  const isLocked = tier === 'locked';
  return (
    <button onClick={onTap} style={{
      all:'unset', cursor: onTap ? 'pointer' : 'default',
      width: size, height: size, borderRadius: '22%',
      background: isLocked ? 'transparent' : t.fill,
      border: isLocked ? `1.5px dashed ${t.ring}` : `1px solid ${t.ring}`,
      boxShadow: isLocked ? 'none' : `0 4px 14px -4px ${t.glow}, inset 0 1px 0 rgba(255,255,255,0.30), inset 0 -1px 0 rgba(0,0,0,0.15)`,
      display:'flex', alignItems:'center', justifyContent:'center',
      flexShrink: 0, position:'relative',
    }}>
      <svg width={size*0.5} height={size*0.5} viewBox="0 0 24 24" fill="none"
        stroke={isLocked ? '#5C6E89' : '#FFF'} strokeWidth="2"
        style={{ filter: isLocked ? 'none' : 'drop-shadow(0 1px 1px rgba(0,0,0,0.25))' }}>
        {BADGE_ICON[b.icon]}
      </svg>
    </button>
  );
}

// ============================================================
// POPOVER — appears on tap. Two density levels (compact / rich)
// ============================================================
function BadgePopoverCompact({ b, onClose, anchorRef }) {
  const tier = b.negative ? 'negative' : tierFor(b.count);
  const t = TIER[tier];
  const nextThreshold = b.count < 10 ? 10 : b.count < 50 ? 50 : null;
  const toNext = nextThreshold ? nextThreshold - b.count : null;
  return (
    <div style={{
      position:'absolute', top:'calc(100% + 8px)', left:'50%', transform:'translateX(-50%)',
      width: 240,
      background: '#243752',
      border: `1px solid ${t.ring}40`,
      borderRadius: 12,
      padding: 12,
      boxShadow: '0 12px 32px -8px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04)',
      zIndex: 50,
      color: '#F5F1EB',
    }}>
      {/* Pointer */}
      <div style={{
        position:'absolute', top: -6, left:'50%', transform:'translateX(-50%) rotate(45deg)',
        width: 12, height: 12, background:'#243752',
        borderTop: `1px solid ${t.ring}40`, borderLeft: `1px solid ${t.ring}40`,
      }}/>
      <div style={{ display:'flex', alignItems:'center', gap: 10, marginBottom: 8 }}>
        <BadgeA b={b} size={32}/>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, lineHeight: 1.2 }}>{b.label}</div>
          <div style={{ fontSize: 10.5, color: t.ring, textTransform:'uppercase', letterSpacing:'0.1em', fontWeight: 700, marginTop: 2 }}>
            {t.label} · ×{b.count}
          </div>
        </div>
      </div>
      <div style={{ fontSize: 11.5, color:'#B8C0CC', lineHeight: 1.45 }}>{b.desc}</div>
      {toNext && !b.negative && (
        <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(255,255,255,0.06)',
          fontSize: 10.5, color:'#8E97A6' }}>
          Encore <span style={{ color:'#FFF', fontWeight: 700 }}>{toNext}</span> pour passer à <span style={{ color: TIER[b.count < 10 ? 'silver' : 'gold'].ring, fontWeight: 700 }}>{TIER[b.count < 10 ? 'silver' : 'gold'].label}</span>
        </div>
      )}
    </div>
  );
}

function BadgePopoverRich({ b }) {
  const tier = b.negative ? 'negative' : tierFor(b.count);
  const t = TIER[tier];
  const nextThreshold = b.count < 10 ? 10 : b.count < 50 ? 50 : null;
  const toNext = nextThreshold ? nextThreshold - b.count : null;
  const progressPct = b.count < 10
    ? (b.count / 10) * 100
    : b.count < 50
      ? ((b.count - 10) / 40) * 100
      : 100;
  return (
    <div style={{
      position:'absolute', top:'calc(100% + 8px)', left:'50%', transform:'translateX(-50%)',
      width: 280,
      background: '#243752',
      border: `1px solid ${t.ring}40`,
      borderRadius: 14,
      padding: 14,
      boxShadow: '0 16px 40px -10px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.04)',
      zIndex: 50,
      color: '#F5F1EB',
    }}>
      <div style={{
        position:'absolute', top: -6, left:'50%', transform:'translateX(-50%) rotate(45deg)',
        width: 12, height: 12, background:'#243752',
        borderTop: `1px solid ${t.ring}40`, borderLeft: `1px solid ${t.ring}40`,
      }}/>
      <div style={{ display:'flex', alignItems:'center', gap: 12, marginBottom: 10 }}>
        <BadgeA b={b} size={44}/>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize: 14, fontWeight: 700, lineHeight: 1.2 }}>{b.label}</div>
          <div style={{ display:'flex', alignItems:'center', gap: 6, marginTop: 3 }}>
            <span style={{ fontSize: 10.5, color: t.ring, textTransform:'uppercase', letterSpacing:'0.1em', fontWeight: 700 }}>
              {t.label}
            </span>
            <span style={{ fontSize: 10.5, color:'#8E97A6' }}>·</span>
            <span style={{ fontSize: 10.5, color:'#B8C0CC' }}>{b.kind === 'peer' ? 'par les membres' : 'par Junto'}</span>
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize: 18, fontWeight: 800, lineHeight: 1, color:'#FFF' }}>×{b.count}</div>
          <div style={{ fontSize: 9, color:'#8E97A6', textTransform:'uppercase', letterSpacing:'0.1em', marginTop: 2 }}>fois</div>
        </div>
      </div>
      <div style={{ fontSize: 12, color:'#D5DCE5', lineHeight: 1.45, marginBottom: 10 }}>{b.desc}</div>
      {b.lastAt && (
        <div style={{ fontSize: 10.5, color:'#8E97A6', marginBottom: 10 }}>
          Dernière obtention&nbsp;: <span style={{ color:'#B8C0CC' }}>{b.lastAt}</span>
        </div>
      )}
      {!b.negative && (
        <div>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize: 9.5, color:'#8E97A6', textTransform:'uppercase', letterSpacing:'0.1em', fontWeight: 600, marginBottom: 5 }}>
            <span>Progression</span>
            <span>{nextThreshold ? `${b.count} / ${nextThreshold}` : 'Or atteint'}</span>
          </div>
          <div style={{
            height: 4, borderRadius: 2,
            background: 'rgba(255,255,255,0.08)',
            overflow:'hidden',
          }}>
            <div style={{
              width: `${progressPct}%`, height:'100%',
              background: t.fill,
              borderRadius: 2,
            }}/>
          </div>
          {toNext && (
            <div style={{ fontSize: 10.5, color:'#8E97A6', marginTop: 6 }}>
              Encore <span style={{ color:'#FFF', fontWeight: 700 }}>{toNext}</span> pour <span style={{ color: TIER[b.count < 10 ? 'silver' : 'gold'].ring, fontWeight: 700 }}>{TIER[b.count < 10 ? 'silver' : 'gold'].label}</span>
            </div>
          )}
        </div>
      )}
      {b.negative && (
        <div style={{
          fontSize: 10.5, color:'#E5524E', marginTop: 4,
          padding: 8, borderRadius: 8,
          background: 'rgba(229, 82, 78, 0.08)',
          border: '1px solid rgba(229, 82, 78, 0.25)',
        }}>
          Ce signal apparaît dès la 1ʳᵉ occurrence et reste affiché 6 mois.
        </div>
      )}
    </div>
  );
}

// Expose to global scope
Object.assign(window, {
  TIER, tierFor, BADGE_ICON, SAMPLE_BADGES,
  BadgeA, BadgeB, BadgeC,
  BadgePopoverCompact, BadgePopoverRich,
});
