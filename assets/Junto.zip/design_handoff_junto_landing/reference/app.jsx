/* App shell with Tweaks support */

const HEADLINES = [
  { line1: 'Trouve, crée,', line2: 'rejoins.' },
  { line1: 'Toutes tes sorties', line2: 'sur une carte.' },
  { line1: 'Ta prochaine sortie', line2: 'commence ici.' },
  { line1: 'Lance une sortie.', line2: 'Ou rejoins-en une.' },
];

const TWEAKS = /*EDITMODE-BEGIN*/{
  "headlineIndex": 0
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweaks] = React.useState(TWEAKS);
  const [panelOpen, setPanelOpen] = React.useState(false);

  React.useEffect(() => {
    const onMsg = (e) => {
      if (!e.data) return;
      if (e.data.type === '__activate_edit_mode') setPanelOpen(true);
      if (e.data.type === '__deactivate_edit_mode') setPanelOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  const updateTweak = (key, value) => {
    setTweaks(t => ({ ...t, [key]: value }));
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [key]: value } }, '*');
  };

  const headline = HEADLINES[tweaks.headlineIndex ?? 0];

  return (
    <>
      <Hero headline={headline}/>
      <Pillars/>
      <HowItWorks/>
      <UpcomingTrips/>
      <Screenshots/>
      <Sports/>
      <FinalCTA/>
      <Footer/>

      {panelOpen && (
        <div style={{
          position: 'fixed', bottom: 24, right: 24, zIndex: 1000,
          background: '#FFF', borderRadius: 16,
          boxShadow: '0 20px 60px -10px rgba(15,24,40,0.35), 0 0 0 1px rgba(15,24,40,0.05)',
          padding: 20, width: 320,
          fontFamily: "'Plus Jakarta Sans', sans-serif",
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#1E2F4D' }}>Tweaks</div>
            <button onClick={() => setPanelOpen(false)} style={{
              background: 'transparent', fontSize: 18, color: '#5B6B85', padding: 0, lineHeight: 1,
            }}>×</button>
          </div>

          <div style={{ fontSize: 12, color: '#5B6B85', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>
            Accroche du hero
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {HEADLINES.map((h, i) => (
              <button key={i} onClick={() => updateTweak('headlineIndex', i)} style={{
                textAlign: 'left', padding: '12px 14px',
                borderRadius: 10,
                background: tweaks.headlineIndex === i ? '#1E2F4D' : '#F4F6FA',
                color: tweaks.headlineIndex === i ? '#FFF' : '#1E2F4D',
                fontSize: 13, lineHeight: 1.35, fontWeight: 500,
                border: 'none', cursor: 'pointer',
              }}>
                <div style={{ fontWeight: 700 }}>{h.line1}</div>
                <div style={{ fontStyle: 'italic', opacity: tweaks.headlineIndex === i ? 0.8 : 0.65 }}>{h.line2}</div>
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
