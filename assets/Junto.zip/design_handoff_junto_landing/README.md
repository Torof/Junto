# Handoff: Junto — Landing Page

## Overview

Landing page pour **Junto**, une application mobile (Android en bêta, iOS à venir) qui permet de trouver, créer et organiser des sorties sportives outdoor près de chez soi. La page est une one-pager marketing dont l'objectif principal est de pousser l'utilisateur à télécharger l'APK (ou scanner le QR code pour un handoff desktop → mobile).

Ton : outdoor, terrain, carto. Pas corporate, pas tech-brochure, pas communautaire-bisounours. Vocabulaire visuel proche d'une carte topographique (contours, pins, grille, échelle, flèche Nord, coordonnées GPS, chemins en pointillés).

## About the Design Files

Les fichiers dans `reference/` sont des **références de design créées en HTML + React via Babel in-browser** — ce sont des prototypes montrant le look et le comportement voulus, **pas du code de production à copier tel quel**. 

Ta mission est de **recréer cette landing dans l'environnement cible** en utilisant ses conventions (si le projet existe déjà) ou en choisissant le framework le plus approprié (Next.js / Astro / Remix / Vite+React recommandés pour une landing statique). 

Dans `reference/` :
- `index.html` — shell HTML avec tokens CSS, polices, entrée React
- `hero.jsx` — Hero + navigation + composants partagés (`TopoLines`, `JuntoMark`, `Pin`, tokens de couleur)
- `sections.jsx` — toutes les autres sections (Pillars, HowItWorks, UpcomingTrips, Screenshots, Sports, FinalCTA, Footer)
- `app.jsx` — shell applicatif (juste utilisé pour les "Tweaks" du prototype — ignorer pour la prod)
- `junto_icon.png` — logo rond de Junto
- `screen_*.jpeg` — captures d'écran de l'app mobile (ratio 1080×2020)

## Fidelity

**High-fidelity.** Les couleurs, typographies, espacements et compositions sont finales. Reproduire pixel-perfect, mais en utilisant le système de composants du codebase cible.

## Design Tokens

### Couleurs
```css
--navy:        #1E2F4D;  /* couleur de marque principale, texte sombre, fond hero */
--navy-deep:   #14223B;  /* fond screenshots, footer */
--navy-dark:   #0F1828;  /* collines les plus proches dans le hero */
--orange:      #F26B2E;  /* accent principal, CTA, pins */
--orange-soft: #F4A373;  /* accent secondaire sur fond sombre */
--cream:       #F4E9D3;  /* fond Sports, soleil dans le hero */
--cream-soft:  #FBF5E6;  /* fond Pillars, UpcomingTrips */
--mint:        #7EC8A3;  /* accent trail */
--sky:         #4B7CB8;  /* accent parapente/eau */
--ink:         #1E2F4D;  /* texte sur fond clair */
--muted:       #5B6B85;  /* texte secondaire */
--line:        #E8E2D1;  /* bordures sur fond cream */
```

### Typographie
Trois familles via Google Fonts :
- **Archivo** (class `.display`) — display, titres, chiffres. Weights 400/500/600/700/800/900. Utilisée avec `font-stretch: 125%`.
- **Inter** — texte courant. Weights 400/500/600/700.
- **JetBrains Mono** (class `.mono`) — labels, kickers, coordonnées GPS, échelles, codes. Weights 400/500.

Import :
```html
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

### Échelles clés
- Titres de section H2 : 64px, lineHeight 0.98, letterSpacing -0.035em, weight 800, textWrap balance.
- H1 du hero : 88px.
- H2 du CTA final : 84px.
- Kicker/mono labels : 11-12px, uppercase, letterSpacing 0.15em-0.2em.
- Corps de texte : 17-19px, lineHeight 1.5-1.55.
- Border radius : 12 / 16 / 20 / 24 pour les cartes, 999 pour les pills.
- Padding sections : `140px 40px`.
- `max-width` du contenu : 1180px (ou 1280px pour hero et screenshots), centré.

## Structure de la page (ordre des sections)

1. **Hero** (`<section>` navy, `min-height: 760px`) — nav + titre + sous-titre + CTA
2. **Pillars** — "Ce que tu fais avec Junto" (3 cartes empilées)
3. **HowItWorks** (`id="comment"`) — "Trois arrêts sur ton itinéraire" (carte topo dark avec 3 pins)
4. **UpcomingTrips** (`id="sorties"`) — "Des sorties, en vrai." (grille 2×2 de sorties de la semaine)
5. **Screenshots** — "Pensée pour le terrain." (4 mockups iPhone)
6. **Sports** — "{N} sports — et ça grandit." (catalogue en table)
7. **FinalCTA** (`id="beta"`) — "Ta prochaine sortie t'attend déjà." + bouton APK + QR code
8. **Footer** — logo + liens + copyright

## Screens / Views

### Hero

- Fond : navy (`#1E2F4D`) avec un SVG plein écran en absolute (`HeroMountains`) :
  - Gradient de ciel (`#2A4268` → navy → navy-deep)
  - Soleil orange-soft `radialGradient` (cx 1100, cy 180, r 280) avec un disque crème `#F4E9D3` à 92% opacité.
  - Étoiles : 11 petits cercles cream à 70% opacité.
  - Contours topo dans le ciel (3 courbes cream à 12% opacité).
  - 3 silhouettes de montagnes superposées avec opacités/couleurs décroissantes (navy-deep 75% → `#0B1728` → `#071221`).
  - 2 chemins dashed : un orange épais, un cream plus fin.
  - 4 pins scatterés (escalade/rando/parapente/VTT) via le composant `Pin`.
- Overlay linear-gradient à 90deg par-dessus pour assombrir la partie gauche et rendre le texte lisible.
- Nav en top (z-index 10) : logo rond Junto + "Junto" en display 24px + liens "Comment ça marche", "Sorties", et un pill blanc "Rejoindre la bêta".
- H1 :
  - 88px display weight 800, letterSpacing -0.035em, lineHeight 0.95.
  - Deux lignes. La deuxième est en `color: orange-soft`.
  - Les 4 variantes de headline existent dans les Tweaks du prototype — pour la prod, garder celle par défaut : `Trouve, crée,` / `rejoins.`
- Sous-titre : 19px, lineHeight 1.5, maxWidth 460, opacity 0.82. Texte : « Trouve, crée, organise tes sorties outdoor. Près de chez toi. »
- CTA : bouton orange "Rejoindre la bêta" + flèche, `boxShadow: 0 10px 30px -8px rgba(242,107,46,0.5)`. À côté, label mono "ANDROID · APK DIRECT" à 60% opacité.
- Grid 1.15fr / 1fr avec la 2e colonne vide (la montagne en absolute occupe l'espace visuel à droite).

### Pillars — "Ce que tu fais avec Junto"

- Fond cream-soft avec `TopoLines` décoratif à 5% opacité (SVG de courbes qui s'étirent sur toute la largeur).
- Label kicker mono (orange) : `Ce que tu fais avec Junto`.
- H2 : `Trouver une sortie. En créer une. S'organiser.` — le dernier segment en orange.
- 3 cartes blanches empilées, border 1px `var(--line)`, radius 24, padding 48/56, grid `1fr 320px`.
- Chaque carte = zone texte à gauche + zone art à droite (height 220, radius 16, overflow hidden).
- Zone texte : numéro XL orange (56px, display) + kicker NAVY (28px) alignés sur baseline, puis titre 36px, puis body 17px muted.
- 3 items :
  1. `Trouve` — "Une carte vivante des sorties autour de toi." — art = carte illustrée (fond `#EFE4CE`, patches de forêt `#C9D9B8`, rivière `#B8D1E3`, lac, routes blanches/orange, grille, 4 pins, marqueur "tu es ici" pulsant en orange).
  2. `Crée` — "Lance ta propre sortie en 30 secondes." — art = fond orange, carte blanche flottante avec un mock "Nouvelle sortie" (titre + date + places + niveau + bouton navy "Publier la sortie").
  3. `Organise` — "Covoiturage, chat, matos — tout au même endroit." — art = fond `#F4EBD9`, 3 bulles de chat mockées (Léa, Moi, Tom).

### HowItWorks — "Trois arrêts sur ton itinéraire."

- Fond navy, `id="comment"`.
- Label mono orange-soft, H2 display 64px (2e ligne en orange-soft).
- Grande surface `aspect-ratio: 16/8`, radius 24, fond `#132238`, border 1px white/8%.
- À l'intérieur, SVG plein cadre viewBox 1400×700 :
  - Pattern de grille (50×50, stroke cream 0.5px, opacity 0.08).
  - 5 contours topo orange-soft à 25% (les "collines").
  - 2-3 contours cream secondaires à 15%.
  - **Chemin principal en pointillés orange** (`strokeDasharray="2 10"`, width 4) qui connecte les 3 pins : `d="M 252 504 C 420 470, 540 420, 700 350 C 860 280, 1000 220, 1148 196"`.
  - Flèche Nord en haut-gauche (80, 60).
  - Échelle "1 KM" en bas-droite (1200, 640).
- Les 3 pins sont des divs en absolute au-dessus du SVG, positionnés à :
  - 18%, 72% — `01 · Trouve · Ouvre la carte.`
  - 50%, 50% — `02 · Rejoins · Un tap, tu es dedans.`
  - 82%, 28% — `03 · Pars · Chat, transport, go.`
- Chaque pin = carte blanche (padding 14/18, radius 12, shadow xl, minWidth 180, textAlign left) avec label mono orange "ÉTAPE 0N", titre 22 display, body 13 muted. En dessous de la carte, un pin SVG 44×56 orange avec un numéro blanc dedans.

### UpcomingTrips — "Des sorties, en vrai."

- Fond cream-soft, `id="sorties"`, `TopoLines` à 4%.
- Grille 2 colonnes de 4 cartes blanches (radius 20, padding 28, border line).
- Chaque carte = `64px 1fr auto` :
  - Gros carré d'accent `{color}22` avec emoji 30px.
  - Centre : ligne mono sport + niveau + detail (séparés par des points), puis lieu display 22, puis date · heure muted 13.
  - Droite : `{participants}/{max}` en display 26 + label "Partants" mono 10.
- Données :
  ```js
  { sport: 'Escalade',    emoji: '🧗', location: 'Calanques, Marseille',      date: 'Dim. 27 avr', time: '9h',   level: 'Tous niveaux',    detail: '6a → 7a',              participants: 4, max: 6,  accent: '#F26B2E' }
  { sport: 'Parapente',   emoji: '🪂', location: 'Col de la Forclaz, Annecy', date: 'Sam. 3 mai',  time: '7h30', level: 'Pilote autonome', detail: 'Déniv. 900 m',         participants: 3, max: 5,  accent: '#4B7CB8' }
  { sport: 'Trail',       emoji: '🏃', location: 'Belledonne, Grenoble',      date: 'Dim. 4 mai',  time: '8h',   level: 'Confirmé',        detail: '25 km · D+ 1 400 m',   participants: 6, max: 10, accent: '#7EC8A3' }
  { sport: 'Ski de rando', emoji: '🎿', location: 'Vallée Blanche, Chamonix',  date: 'Sam. 10 mai', time: '5h30', level: 'Confirmé',        detail: 'D+ 1 200 m',           participants: 2, max: 4,  accent: '#F4A373' }
  ```

### Screenshots — "Pensée pour le terrain."

- Fond navy-deep, TopoLines cream 4%.
- Grille 4 colonnes, gap 28.
- Chaque "phone" = wrapper avec gradient bezel (`#2A3E5F` → `#182238`), padding 8, radius 32, shadow `0 40px 60px -20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.08)`.
- Effet de décalage vertical : les index impairs ont `translateY(28px)`.
- Intérieur : aspect-ratio 1080/2020, radius 26, overflow hidden, `<img>` avec `object-fit: contain`, `object-position: top`.
- 4 screens : `screen_map.jpeg` (La carte), `screen_popup.jpeg` (Un aperçu), `screen_activity.jpeg` (Le détail), `screen_profile.jpeg` (Le profil).
- Sous chaque phone, centré : numéro mono orange-soft "0N" + titre display 20.

### Sports

- Fond cream, TopoLines navy 5%.
- H2 : `{total} sports — et ça grandit.` avec le nombre en orange.
- Table custom : chaque ligne = grid `200px 1fr`, borderBottom line.
- Colonne gauche : pastille colorée + nom catégorie display 22 + compteur mono "0N".
- Colonne droite : liste de sports séparés par des points gris (fontSize 17, weight 500).
- 6 catégories (voir `sections.jsx` lignes 465-520 pour la liste exacte).
- Sous la table : petit texte "Un sport manque ? [mailto link]".

### FinalCTA — "Ta prochaine sortie t'attend déjà."

- Fond navy + 2 radial-gradients (orange 80%/20% et sky 20%/80%) + TopoLines cream 6%.
- H2 display 84px (2e ligne orange-soft).
- Flex center avec gap 40 :
  - **Gauche** : bouton orange "Télécharger l'APK" avec icône download, padding 18/28, radius 12. En dessous, mono "ANDROID 9+ · ~24 MO".
  - **Droite** : label mono vertical "OU SCANNE →" (`writingMode: vertical-rl`, `rotate(180deg)`) + QR code 140×140 blanc radius 16 padding 12.
- QR code est un SVG généré (viewBox 100×100, 3 finder patterns aux coins + pattern pseudo-aléatoire). En prod, remplacer par un **vrai QR code** pointant vers le lien de download APK (via `qrcode` npm package ou un service).
- Petit lien sous : "iOS bientôt — demande TestFlight".

### Footer

- Fond navy-deep, padding 56/40/40.
- Flex horizontal : logo + mail à gauche, 2 colonnes de liens à droite (PRODUIT, LÉGAL).
- Sous-ligne borderTop : copyright + `MADE IN FRANCE 🏔️` en mono.

## Composants partagés à extraire

### `<SectionLabel color?>`
Kicker mono avec un trait à gauche. Couleur par défaut orange.
```jsx
<SectionLabel>Ce que tu fais avec Junto</SectionLabel>
<SectionLabel color={ORANGE_SOFT}>Rejoins la bêta</SectionLabel>
```

### `<TopoLines opacity color count>`
Couche décorative de courbes topo en absolute. Utilisée dans plusieurs sections. Voir `hero.jsx` pour l'implémentation (14 courbes par défaut, générées algorithmiquement).

### `<Pin x y color emoji dark?>`
Pin SVG en forme de goutte, pour le hero et la carte. 52×64, stroke navy-deep 2.5.

### `<JuntoMark size>`
Juste l'image `junto_icon.png` avec `borderRadius: 50%`.

## Interactions & Behavior

- Liens d'ancre dans la nav : `#comment`, `#sorties`, `#beta`.
- Tous les CTAs "Rejoindre la bêta" pointent vers `#beta`.
- Le bouton "Télécharger l'APK" doit pointer vers l'URL réelle de l'APK hébergée.
- Le lien TestFlight iOS pointe vers `mailto:contact@getjunto.app`.
- Pas d'animations ou de transitions complexes. Tout est statique.
- **Responsive** : le design actuel est desktop-only. Pour mobile :
  - Réduire H1 à ~48px, H2 à ~40px.
  - Passer les grilles à 1 colonne.
  - Dans Hero, le `grid 1.15fr 1fr` devient `1fr` (pas besoin de cacher la 2e colonne).
  - Dans Screenshots, passer à grille 2 colonnes puis 1.
  - HowItWorks : la carte 16/8 devient 4/5 sur mobile et les 3 pins se réorganisent verticalement (alt : remplacer par un stack de 3 cartes).
  - FinalCTA : QR + bouton passent en colonne.

## Assets

- `junto_icon.png` — logo rond Junto. Utilisé dans la nav et le footer.
- 4 screenshots mobiles (1080×2020) — mockups de l'app.
- Aucune autre image. Tout le reste est SVG inline ou CSS.

## Dépendances recommandées

Pour une implémentation production-ready (Next.js / Vite) :
- `next` ou `react` + `vite`
- `qrcode.react` (pour le vrai QR code)
- Fonts via `next/font/google` (ou `@fontsource/archivo`, `@fontsource/inter`, `@fontsource/jetbrains-mono`)

## Notes finales

- Les couleurs sont précises. Ne pas dériver un thème automatisé, coller aux hex.
- Le `font-stretch: 125%` sur Archivo est important, il donne sa signature "expandée" au display.
- Le `textWrap: balance` sur les gros titres n'est pas optionnel — ça répartit les lignes proprement.
- Les `TopoLines` et les courbes sont l'ADN visuel — ne pas les enlever même si elles semblent "décoratives". Elles font la marque.
- Pour tester que tout s'affiche, ouvrir `reference/index.html` dans un navigateur (pas besoin de serveur, tout est CDN).

## Files

Voir `reference/` : tous les fichiers source du prototype HTML y sont dupliqués.
