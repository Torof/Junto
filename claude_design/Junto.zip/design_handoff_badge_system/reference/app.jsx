/* BadgeSystem — design canvas presenting tier badges, popovers, profile mocks */

function Section({ id, title, kicker, lede, children }) {
  return (
    <DCSection id={id} title={title}>
      <div style={{ display:'flex', flexDirection:'column', gap: 18, padding: '0 8px 24px', maxWidth: 1100 }}>
        {kicker && <div style={{ fontSize: 11, fontWeight: 700, color:'#F26B2E', textTransform:'uppercase', letterSpacing:'0.16em' }}>{kicker}</div>}
        {lede && <div style={{ fontSize: 14, color:'#566073', lineHeight: 1.55, maxWidth: 760 }}>{lede}</div>}
        {children}
      </div>
    </DCSection>
  );
}

// FOCUSED SHOWCASE — variante B, 4 badges peer aux 3 tiers + popover
function FocusedShowcase() {
  const four = [
    { id:'trust',    label:'De confiance',   icon:'shield-check' },
    { id:'leader',   label:'Super leader',   icon:'star' },
    { id:'ambiance', label:'Bonne ambiance', icon:'smile' },
    { id:'punctual', label:'Ponctuel',       icon:'clock' },
  ];
  const tiers = [
    { tier:'bronze', count: 5,  desc:(n)=>`5 personnes t'ont attribué ce badge.` },
    { tier:'silver', count: 28, desc:(n)=>`28 personnes t'ont attribué ce badge.` },
    { tier:'gold',   count: 64, desc:(n)=>`64 personnes t'ont attribué ce badge.` },
  ];

  // Scroll-stopper hero: 12 badges (4 × 3 tiers) in a grid with labels
  return (
    <div style={{
      background:'#0F1A2E', borderRadius: 16, padding: 32,
      border:'1px solid rgba(255,255,255,0.06)',
    }}>
      {/* Tier rows */}
      {tiers.map(t => (
        <div key={t.tier} style={{ marginBottom: 26, paddingBottom: 26, borderBottom:'1px solid rgba(255,255,255,0.06)' }}>
          <div style={{ display:'flex', alignItems:'baseline', gap: 12, marginBottom: 18 }}>
            <div style={{
              fontSize: 11, fontWeight: 700, color: TIER[t.tier].ring,
              textTransform:'uppercase', letterSpacing:'0.18em',
              padding: '4px 10px', borderRadius: 4,
              background: TIER[t.tier].fillSoft,
              border: `1px solid ${TIER[t.tier].ring}40`,
            }}>{TIER[t.tier].label}</div>
            <div style={{ fontSize: 12, color:'#8E97A6' }}>
              {t.tier === 'bronze' && '1 à 9 obtentions'}
              {t.tier === 'silver' && '10 à 49 obtentions'}
              {t.tier === 'gold' && '50+ obtentions'}
            </div>
          </div>
          <div style={{ display:'flex', gap: 28, alignItems:'flex-start' }}>
            {four.map(b => {
              const badge = { ...b, kind:'peer', count: t.count, desc: t.desc() };
              return (
                <div key={b.id} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 8, width: 80 }}>
                  <BadgeB b={badge} size={56}/>
                  <div style={{ fontSize: 12, color:'#FFF', fontWeight: 600, textAlign:'center', lineHeight: 1.2 }}>{b.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* Popover open on a Silver badge */}
      <div style={{ paddingTop: 6 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color:'#F26B2E', textTransform:'uppercase', letterSpacing:'0.18em', marginBottom: 16 }}>
          Tap → popover riche
        </div>
        <div style={{ display:'flex', gap: 28, alignItems:'flex-start', position:'relative', minHeight: 320 }}>
          {four.map((b, i) => {
            const tier = tiers[1]; // silver across the row
            const badge = { ...b, kind:'peer', count: tier.count,
              desc: i === 0 ? "28 personnes t'ont marqué·e comme un partenaire de confiance après une sortie." : tier.desc(),
              lastAt: i === 0 ? '12 mars 2026' : undefined,
            };
            return (
              <div key={b.id} style={{
                display:'flex', flexDirection:'column', alignItems:'center', gap: 8,
                width: 80, position:'relative',
              }}>
                <BadgeB b={badge} size={56}/>
                <div style={{ fontSize: 12, color:'#FFF', fontWeight: 600, textAlign:'center', lineHeight: 1.2 }}>{b.label}</div>
                {i === 0 && <BadgePopoverRich b={badge}/>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
function TierShowcase() {
  const samples = [
    { tier: 'gold',     badge: { id:'gold-mordu',   label:'Mordu Parapente',  icon:'paraglide',    kind:'auto', count: 92, desc:"92 sorties parapente terminées." }},
    { tier: 'silver',   badge: { id:'silver-trust', label:'De confiance',     icon:'shield-check', kind:'peer', count: 30, desc:"30 personnes t'ont marqué·e comme un partenaire de confiance.", lastAt:'12 mars 2026' }},
    { tier: 'bronze',   badge: { id:'bronze-curi',  label:'Curieux Escalade', icon:'mountain',     kind:'auto', count: 6,  desc:"6 sorties terminées dans une nouvelle discipline (escalade)." }},
    { tier: 'negative', badge: { id:'neg-noshow',   label:'Désistement',      icon:'ghost',        kind:'peer', count: 2,  negative:true, desc:"Signalé·e 2 fois pour ne pas s'être présenté·e à la sortie." }},
  ];
  return (
    <div style={{ display:'flex', gap: 24, flexWrap:'wrap' }}>
      {samples.map(s => (
        <div key={s.tier} style={{
          background:'#0F1A2E', borderRadius: 14, padding: 24,
          width: 240,
          display:'flex', flexDirection:'column', alignItems:'center', gap: 14,
          border: `1px solid ${TIER[s.tier].ring}30`,
        }}>
          <BadgeA b={s.badge} size={88}/>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: TIER[s.tier].ring, textTransform:'uppercase', letterSpacing:'0.14em', marginBottom: 4 }}>
              {TIER[s.tier].label}
            </div>
            <div style={{ fontSize: 14, fontWeight: 700, color:'#FFF', marginBottom: 4 }}>{s.badge.label}</div>
            <div style={{ fontSize: 11, color:'#8E97A6' }}>
              {s.tier === 'gold' && '50+ fois'}
              {s.tier === 'silver' && '10–49 fois'}
              {s.tier === 'bronze' && '1–9 fois'}
              {s.tier === 'negative' && 'signal négatif'}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// Variant comparator: A/B/C
function VariantComparator() {
  const sample = { id:'demo', label:'De confiance', icon:'shield-check', kind:'peer', count: 30, desc:"30 personnes t'ont marqué·e comme un partenaire de confiance." };
  const tiers = ['bronze', 'silver', 'gold'];
  const sampleByTier = (t) => ({
    ...sample,
    count: t === 'bronze' ? 5 : t === 'silver' ? 30 : 75,
  });

  const variants = [
    { key: 'A', name: 'A. Coloré pleine teinte', desc: 'Le badge prend la couleur du tier. Lecture immédiate du niveau, perte du code couleur de catégorie.', Comp: BadgeA },
    { key: 'B', name: 'B. Anneau de tier', desc: 'Anneau coloré autour d\'un disque navy neutre. Plus discret, garde la cohérence avec le UI sombre.', Comp: BadgeB },
    { key: 'C', name: 'C. Coin facetté', desc: 'Forme arrondi-carré (coin de jeu). Plus collectible, plus jeu vidéo. Différencie du reste de l\'UI.', Comp: BadgeC },
  ];

  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap: 16 }}>
      {variants.map(v => (
        <div key={v.key} style={{
          background:'#0F1A2E', borderRadius: 14, padding: 20,
          border: '1px solid rgba(255,255,255,0.06)',
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color:'#F26B2E', textTransform:'uppercase', letterSpacing:'0.14em', marginBottom: 4 }}>
            Variante {v.key}
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color:'#FFF', marginBottom: 6 }}>{v.name}</div>
          <div style={{ fontSize: 12, color:'#8E97A6', marginBottom: 18, lineHeight: 1.45, minHeight: 50 }}>{v.desc}</div>
          {/* Three tiers + negative + locked */}
          <div style={{ display:'flex', gap: 14, alignItems:'center', justifyContent:'center', flexWrap:'wrap', marginBottom: 12 }}>
            {tiers.map(t => (
              <div key={t} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 6 }}>
                <v.Comp b={sampleByTier(t)} size={48}/>
                <div style={{ fontSize: 9.5, color: TIER[t].ring, textTransform:'uppercase', letterSpacing:'0.1em', fontWeight: 700 }}>{TIER[t].label}</div>
              </div>
            ))}
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 6 }}>
              <v.Comp b={{ ...sample, count: 2, negative: true, icon: 'ghost' }} size={48}/>
              <div style={{ fontSize: 9.5, color: TIER.negative.ring, textTransform:'uppercase', letterSpacing:'0.1em', fontWeight: 700 }}>Signal</div>
            </div>
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 6 }}>
              <v.Comp b={{ ...sample, count: 0 }} size={48}/>
              <div style={{ fontSize: 9.5, color:'#5C6E89', textTransform:'uppercase', letterSpacing:'0.1em', fontWeight: 700 }}>Verrou.</div>
            </div>
          </div>
          {/* Mini-row at "real" 36px size */}
          <div style={{
            background:'#1E2F4D', borderRadius: 8, padding: 10,
            display:'flex', gap: 6, alignItems:'center',
          }}>
            <v.Comp b={{ ...sample, count: 75, icon:'shield-check' }} size={36}/>
            <v.Comp b={{ ...sample, count: 30, icon:'star',         label:'Leader' }} size={36}/>
            <v.Comp b={{ ...sample, count: 28, icon:'smile',        label:'Ambiance' }} size={36}/>
            <v.Comp b={{ ...sample, count: 6,  icon:'mountain',     label:'Curieux' }} size={36}/>
            <v.Comp b={{ ...sample, count: 2,  icon:'ghost', negative:true }} size={36}/>
            <button style={{
              all:'unset', cursor:'pointer',
              width: 36, height: 36, borderRadius:'50%',
              border: '1.5px dashed #5C6E89',
              color:'#B8C0CC', fontSize: 11, fontWeight: 700,
              display:'flex', alignItems:'center', justifyContent:'center',
            }}>+4</button>
          </div>
          <div style={{ fontSize: 10, color:'#5C6E89', marginTop: 8, textAlign:'center' }}>Taille réelle dans le profil</div>
        </div>
      ))}
    </div>
  );
}

// Popover comparator
function PopoverComparator() {
  const sample = { id:'demo', label:'De confiance', icon:'shield-check', kind:'peer', count: 30, desc:"30 personnes t'ont marqué·e comme un partenaire de confiance.", lastAt:'12 mars 2026' };
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap: 24 }}>
      <div style={{
        background:'#0F1A2E', borderRadius: 14, padding: 20,
        border: '1px solid rgba(255,255,255,0.06)',
      }}>
        <div style={{ fontSize: 11, fontWeight: 700, color:'#F26B2E', textTransform:'uppercase', letterSpacing:'0.14em', marginBottom: 4 }}>
          Popover compact
        </div>
        <div style={{ fontSize: 15, fontWeight: 700, color:'#FFF', marginBottom: 6 }}>L'essentiel</div>
        <div style={{ fontSize: 12, color:'#8E97A6', marginBottom: 18, lineHeight: 1.45 }}>
          Titre · tier · ×count · description · prochain palier. 240px de large, lecture en 2s.
        </div>
        <div style={{ position:'relative', height: 200, display:'flex', alignItems:'flex-start', justifyContent:'center', paddingTop: 16 }}>
          <div style={{ position:'relative' }}>
            <BadgeA b={sample} size={36}/>
            <BadgePopoverCompact b={sample}/>
          </div>
        </div>
      </div>

      <div style={{
        background:'#0F1A2E', borderRadius: 14, padding: 20,
        border: '1px solid rgba(255,255,255,0.06)',
      }}>
        <div style={{ fontSize: 11, fontWeight: 700, color:'#F26B2E', textTransform:'uppercase', letterSpacing:'0.14em', marginBottom: 4 }}>
          Popover riche
        </div>
        <div style={{ fontSize: 15, fontWeight: 700, color:'#FFF', marginBottom: 6 }}>+ progression et date</div>
        <div style={{ fontSize: 12, color:'#8E97A6', marginBottom: 18, lineHeight: 1.45 }}>
          Ajoute la barre de progression vers le palier suivant et la date de la dernière obtention. 280px.
        </div>
        <div style={{ position:'relative', height: 280, display:'flex', alignItems:'flex-start', justifyContent:'center', paddingTop: 16 }}>
          <div style={{ position:'relative' }}>
            <BadgeA b={sample} size={36}/>
            <BadgePopoverRich b={sample}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// Negative example with rich popover
function NegativeShowcase() {
  const neg = { id:'neg', label:'Désistement', icon:'ghost', kind:'peer', count: 2, negative:true, desc:"Signalé·e 2 fois pour ne pas s'être présenté·e à la sortie.", lastAt:'18 fév. 2026' };
  return (
    <div style={{
      background:'#0F1A2E', borderRadius: 14, padding: 24,
      border: '1px solid rgba(229, 82, 78, 0.25)',
      display:'flex', gap: 30, alignItems:'flex-start',
    }}>
      <div style={{ position:'relative', paddingTop: 4 }}>
        <BadgeA b={neg} size={56}/>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: TIER.negative.ring, textTransform:'uppercase', letterSpacing:'0.14em', marginBottom: 6 }}>
          Signaux négatifs
        </div>
        <div style={{ fontSize: 18, fontWeight: 800, color:'#FFF', marginBottom: 8 }}>
          Visibles dès la 1ʳᵉ occurrence
        </div>
        <div style={{ fontSize: 13, color:'#B8C0CC', lineHeight: 1.5, marginBottom: 12, maxWidth: 580 }}>
          Les options négatives du peer review (désistement, comportement à risque, retard chronique) génèrent un badge rouge/noir. Pas de notion de bronze/argent/or — un seul tier "Signal", visibilité immédiate. Auto-expire après 6 mois pour ne pas pénaliser à vie.
        </div>
        <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
          {[
            { label:'Désistement', icon:'ghost', count: 2 },
            { label:'En retard', icon:'clock', count: 1 },
            { label:'Sécurité', icon:'alert', count: 1 },
          ].map(b => (
            <div key={b.label} style={{
              display:'flex', alignItems:'center', gap: 8,
              padding: '6px 10px 6px 6px',
              background:'rgba(229, 82, 78, 0.08)',
              border:'1px solid rgba(229, 82, 78, 0.25)',
              borderRadius: 999,
            }}>
              <BadgeA b={{ ...b, kind:'peer', negative:true }} size={28}/>
              <span style={{ fontSize: 12, color:'#FFF', fontWeight: 600 }}>{b.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function App() {
  const phoneFrame = (children) => (
    <div style={{
      width: 392, height: 720,
      background:'#000', borderRadius: 36,
      padding: 6,
      boxShadow:'0 30px 80px -20px rgba(0,0,0,0.4)',
    }}>
      <div style={{
        width:'100%', height:'100%', borderRadius: 30,
        overflow:'hidden', background:'#0F1A2E',
        position:'relative',
      }}>
        {/* status bar */}
        <div style={{
          height: 28,
          display:'flex', alignItems:'center', justifyContent:'space-between',
          padding: '0 18px',
          fontSize: 11, fontWeight: 600, color:'#FFF',
        }}>
          <span>Orange F · 21:29</span>
          <span style={{ display:'flex', gap: 6, alignItems:'center' }}>
            <span style={{ display:'inline-block', width: 12, height: 12, background:'#FFF', WebkitMask:'url(data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="black" d="M2 22h20V2"/></svg>) center/contain no-repeat' }}/>
          </span>
        </div>
        {children}
      </div>
    </div>
  );

  return (
    <DesignCanvas>
      <Section
        id="focused"
        kicker="Choix retenu · variante B"
        title="Anneau de tier, label dessous, chiffres dans le popover"
        lede="Les 4 peer reviews principales — De confiance, Super leader, Bonne ambiance, Ponctuel — déclinés sur les trois tiers. En bas, l'état tappé avec le popover riche ouvert."
      >
        <FocusedShowcase/>
      </Section>

      <Section
        id="overview"
        kicker="Système de badges · v2"
        title="Tiers bronze / argent / or, signal négatif, popover pour les détails"
        lede="L'idée : enlever le compteur du badge (lecture noyée), introduire 3 tiers visibles à 36px, garder l'icône + le label comme code catégorie, et déplacer toutes les métadonnées dans un popover sur tap. Bonus : un tier négatif rouge/noir pour les peer reviews négatives."
      >
        <TierShowcase/>
      </Section>

      <Section
        id="variants"
        kicker="01 — Variantes du badge"
        title="Trois pistes graphiques pour le tier"
        lede="Comparaison à taille réelle (36px) et grossie. La variante A est la plus lisible mais perd la couleur de catégorie. La B garde plus de cohérence visuelle. La C tape plus jeu vidéo / collectible."
      >
        <VariantComparator/>
      </Section>

      <Section
        id="popovers"
        kicker="02 — Popover sur tap"
        title="Compact ou riche selon ce qu'on veut afficher"
        lede="Le popover est ancré sur le badge tappé, avec un pointeur. Le compact suffit pour la plupart des badges. Le riche ajoute la progression vers le palier suivant — utile pour motiver à débloquer le palier suivant."
      >
        <PopoverComparator/>
      </Section>

      <Section
        id="negative"
        kicker="03 — Tier négatif"
        title="Les signaux ne sont pas des badges, mais ils en partagent le langage"
        lede=""
      >
        <NegativeShowcase/>
      </Section>

      <Section
        id="context"
        kicker="04 — En contexte"
        title="Avant / après dans la zone Badges du profil"
        lede="L'écran de profil avec, à gauche, l'implémentation actuelle (deux lignes, chiffres collés sur les badges, 3 « Curieux » qui se ressemblent). À droite, la nouvelle version : une seule ligne, badges réduits à 36px, + le bouton « +4 » overflow et un lien « Voir tout » à droite."
      >
        <div style={{ display:'flex', gap: 32, alignItems:'flex-start', flexWrap:'wrap' }}>
          <DCArtboard id="before" label="Actuel — 2 lignes, chiffres affichés" width={392} height={720}>
            {phoneFrame(<ProfileBefore/>)}
          </DCArtboard>
          <DCArtboard id="after-A" label="Nouveau — variante A (couleur tier)" width={392} height={720}>
            {phoneFrame(<ProfileAfter variant="A"/>)}
          </DCArtboard>
          <DCArtboard id="after-B" label="Nouveau — variante B (anneau tier)" width={392} height={720}>
            {phoneFrame(<ProfileAfter variant="B"/>)}
          </DCArtboard>
          <DCArtboard id="after-A-tap" label="Nouveau — popover ouvert" width={392} height={720}>
            {phoneFrame(<ProfileAfter variant="A" popoverStyle="rich" highlightId="trust"/>)}
          </DCArtboard>
        </div>
      </Section>

      <Section
        id="rules"
        kicker="05 — Règles du système"
        title="Les seuils, les tris, les invariants"
        lede=""
      >
        <div style={{ display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap: 16 }}>
          {[
            { t:'Seuils', d:'Bronze 1–9 · Argent 10–49 · Or 50+. À la 10ᵉ et la 50ᵉ obtention, micro-animation de promotion (le badge change de tier devant l\'utilisateur).' },
            { t:'Affichage profil', d:'6 badges max sur la ligne principale, triés : peer (membres) d\'abord, puis Junto, puis par count décroissant. Les négatifs sont épinglés en fin de ligne, jamais cachés derrière "+N".' },
            { t:'Popover (tap)', d:'Bottom sheet sur mobile, popover ancré sur desktop. Contient : titre, tier, count, description, dernière obtention, progression vers palier suivant. Tap hors zone pour fermer.' },
            { t:'Tier négatif', d:'Rouge/noir, toujours visible dès la 1ʳᵉ occurrence, expire automatiquement après 6 mois. Pas de promotion vers d\'autres tiers — un signal reste un signal.' },
            { t:'Verrouillé', d:'Les badges jamais débloqués n\'apparaissent pas sur le profil. Visibles dans l\'écran "Voir tout" comme objectifs (cercle pointillé).' },
            { t:'Collisions de label', d:'Plus de 3 « Curieux » qui se ressemblent. Si un badge se décline par discipline, on suffixe : « Curieux Escalade », « Curieux Canyoning ». Le tier les ordonne naturellement.' },
          ].map(r => (
            <div key={r.t} style={{
              background:'#0F1A2E', borderRadius: 12, padding: 16,
              border:'1px solid rgba(255,255,255,0.06)',
            }}>
              <div style={{ fontSize: 13, fontWeight: 700, color:'#F26B2E', marginBottom: 6 }}>{r.t}</div>
              <div style={{ fontSize: 12.5, color:'#B8C0CC', lineHeight: 1.55 }}>{r.d}</div>
            </div>
          ))}
        </div>
      </Section>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
