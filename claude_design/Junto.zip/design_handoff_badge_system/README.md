# Handoff — Badge System v2 (Junto)

## Overview

Refonte du système de badges affichés sur le profil utilisateur. Le but est de remplacer l'affichage actuel (badges colorés avec compteur "×N" superposé, deux lignes séparées « Décernés par les membres » / « Décernés par Junto ») par un **système à 3 tiers** (Bronze / Argent / Or) plus un **tier négatif** pour les signalements peer review.

L'utilisateur lit le tier au premier coup d'œil grâce à la couleur d'un anneau autour du badge ; les chiffres et détails passent dans un **popover sur tap**.

## About the Design Files

Les fichiers fournis dans `reference/` sont des **maquettes HTML/React (Babel inline)** — un prototype montrant l'intention visuelle et le comportement. Ils ne sont **pas du code de production**. La mission est de **recréer ces designs dans l'environnement existant de l'app Junto** (React Native attendu, vu les screenshots), en utilisant ses patterns et librairies établis.

Pour visualiser le design :
- **Recommandé** : ouvrir `reference/standalone.html` dans n'importe quel navigateur (auto-contenu, fonctionne offline, aucune installation).
- Alternatif : ouvrir `reference/index.html` (charge React/Babel via CDN, nécessite internet).

Le dossier `screenshots/` contient des captures haute résolution de chaque section pour référence visuelle rapide :
- `01-states.png` à `06-states.png` — captures par scroll de toute la canvas (du choix retenu en haut jusqu'aux règles système en bas).

## Fidelity

**Hi-fi.** Couleurs, typographies, paddings, radii et comportements (popover, hover, etc.) sont définitifs. À reproduire pixel-perfect dans le langage cible, en réutilisant les composants/tokens existants si présents.

---

## 1. Modèle de données

### `Badge` (interface)

```ts
type BadgeKind = 'peer' | 'auto'   // peer = décerné par d'autres membres ; auto = décerné par Junto

type BadgeId =
  // Peer reviews positives
  | 'trust' | 'leader' | 'ambiance' | 'punctual'
  // Peer reviews négatives (tier rouge)
  | 'noshow' | 'late' | 'unsafe'
  // Auto (système)
  | 'regular' | 'animator' | 'curious' | 'mordu' | ...

interface Badge {
  id: string;                  // ex: 'trust', 'curious-escalade'
  label: string;               // ex: 'De confiance', 'Curieux Escalade'
  icon: BadgeIconName;         // voir liste dans badges.jsx
  kind: BadgeKind;             // 'peer' | 'auto'
  count: number;               // nombre de fois débloqué
  negative?: boolean;          // true → tier négatif (rouge), ignore les seuils
  desc: string;                // texte affiché dans le popover (1–2 phrases)
  lastAt?: string;             // date ISO ou string formattée — affichée si présente
}
```

### Calcul du tier

```ts
function tierFor(count: number): 'locked' | 'bronze' | 'silver' | 'gold' {
  if (count <= 0) return 'locked';   // jamais débloqué — non affiché sur le profil
  if (count < 10) return 'bronze';
  if (count < 50) return 'silver';
  return 'gold';
}
```

**Si `badge.negative === true`** → le tier est forcé à `'negative'`, peu importe `count`.

---

## 2. Design Tokens

### Palette des tiers (anneau coloré)

| Tier      | Ring      | Fill (gradient 160°)                                | Glow                          | Label |
| --------- | --------- | --------------------------------------------------- | ----------------------------- | ----- |
| `bronze`  | `#B87333` | `linear-gradient(160deg, #D4894C 0%, #8C5424 100%)` | `rgba(184, 115, 51, 0.45)`    | Bronze |
| `silver`  | `#B8C4CF` | `linear-gradient(160deg, #DCE3EB 0%, #8B95A1 100%)` | `rgba(184, 196, 207, 0.45)`   | Argent |
| `gold`    | `#E8B547` | `linear-gradient(160deg, #F5CD63 0%, #B8862C 100%)` | `rgba(232, 181, 71, 0.55)`    | Or |
| `negative`| `#E5524E` | `linear-gradient(160deg, #E5524E 0%, #7A1A1A 100%)` | `rgba(229, 82, 78, 0.45)`     | Signal |
| `locked`  | `#3A4A66` | (transparent + dashed border)                       | none                          | Verrouillé |

### Couleurs UI ambiantes

| Token              | Hex          | Usage |
| ------------------ | ------------ | ----- |
| `--bg`             | `#0F1A2E`    | Fond app |
| `--panel`          | `#1E2F4D`    | Card / surface |
| `--panel-2`        | `#243752`    | Popover |
| `--text`           | `#FFFFFF`    | Titre |
| `--text-dim`       | `#B8C0CC`    | Body |
| `--text-muted`     | `#8E97A6`    | Méta |
| `--text-subtle`    | `#5C6E89`    | Très secondaire |
| `--orange`         | `#F26B2E`    | Accent CTA |
| `--green-good`     | `#7EC8A3`    | États positifs |

### Typographie

- **Famille primaire** : Archivo (existante dans l'app)
- **Famille mono** (kickers, méta) : JetBrains Mono (existante dans l'app)

| Élément | Taille | Weight | Letter-spacing | Notes |
| ------- | ------ | ------ | -------------- | ----- |
| Label sous badge | 12px | 600 | normal | line-height 1.2 |
| Label tier (popover) | 10.5px | 700 | 0.10em | uppercase |
| Titre badge (popover) | 14px | 700 | normal | |
| Description (popover) | 12px | 400 | normal | line-height 1.45 |
| Méta date (popover) | 10.5px | 400 | normal | color: text-muted |

### Tailles & espacements

| Contexte | Diamètre badge | Gap horizontal | Notes |
| -------- | -------------- | -------------- | ----- |
| Profil (rangée principale) | **40px** | 6px | label dessous |
| Popover (header) | 44px | — | |
| Bottom sheet "Voir tout" | 56px | 28px | grille |
| Hero / écrans dédiés | 56–88px | — | |

**Anneau de tier (variante B retenue)** :
- Padding intérieur : `2.5px` (anneau)
- Disque intérieur : `--bg` ou `--panel` selon contexte
- Icône SVG centrée, stroke `#FFF`, stroke-width `2`, taille = 46% du diamètre

### Box-shadow / glow

- Badges actifs : `0 4px 12px -4px <tier.glow>`
- Popover : `0 16px 40px -10px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.04)`

### Border-radius

- Badge : 50% (rond)
- Popover : 14px
- Pointeur popover : carré 12×12 rotaté 45°

---

## 3. Composant `<Badge />` (variante B retenue)

### Anatomie

```
┌──────────────────────┐
│  ╭────────────────╮  │  ← anneau de tier (gradient)
│  │  ╭──────────╮  │  │
│  │  │   icon   │  │  │  ← disque intérieur navy + icône blanche
│  │  ╰──────────╯  │  │
│  ╰────────────────╯  │
│   "De confiance"     │  ← label (12px, weight 600, blanc)
└──────────────────────┘
```

### Props

```ts
interface BadgeProps {
  badge: Badge;            // données
  size?: number;           // diamètre, default 40
  showLabel?: boolean;     // afficher le label sous le badge, default true sur profil
  onTap?: () => void;      // → déclenche popover
}
```

### Implémentation pseudo-code (à adapter au framework cible)

```jsx
function Badge({ badge, size = 40, showLabel = true, onTap }) {
  const tier = badge.negative ? 'negative' : tierFor(badge.count);
  const t = TIER[tier];
  const isLocked = tier === 'locked';

  return (
    <Pressable onPress={onTap} style={{ alignItems: 'center', gap: 4 }}>
      {/* Anneau */}
      <View style={{
        width: size, height: size, borderRadius: size / 2,
        padding: 2.5,
        background: t.fill,                 // gradient en RN: utiliser LinearGradient
        shadowColor: t.glow,                // adapter pour RN
        shadowOffset: { width: 0, height: 4 },
        shadowRadius: 12,
      }}>
        {/* Disque intérieur */}
        <View style={{
          flex: 1, borderRadius: size / 2,
          backgroundColor: '#1E2F4D',
          alignItems: 'center', justifyContent: 'center',
        }}>
          <BadgeIcon name={badge.icon} size={size * 0.46} color="#FFF" />
        </View>
      </View>

      {showLabel && (
        <Text numberOfLines={2} style={{
          fontSize: 12, fontWeight: '600', color: '#FFF',
          textAlign: 'center', lineHeight: 14, maxWidth: size + 12,
        }}>
          {badge.label}
        </Text>
      )}
    </Pressable>
  );
}
```

### Icônes (SVG)

Liste complète avec paths dans `reference/badges.jsx` (`BADGE_ICON` map). À reproduire en SVG ou en composants `react-native-svg`. Toutes ont `viewBox="0 0 24 24"`, fill `none`, stroke `#FFF`, stroke-width `2`.

Catalogue : `shield`, `shield-check`, `star`, `smile`, `clock`, `bolt`, `flag`, `mountain`, `wave`, `paraglide`, `flame`, `alert`, `ghost`, `cross`.

### États

| État | Représentation |
| ---- | -------------- |
| Bronze (1–9) | Anneau cuivré + disque navy + icône blanche |
| Argent (10–49) | Anneau argent clair + disque navy + icône blanche |
| Or (50+) | Anneau doré + disque navy + icône blanche |
| Signal négatif | Anneau rouge dégradé noir + disque navy + icône blanche |
| Verrouillé | Cercle pointillé `#3A4A66`, transparent, icône `#5C6E89` (uniquement écran "Voir tout") |
| Tap (active) | Scale 0.95, durée 100ms |

---

## 4. Composant `<BadgePopover />` (popover riche retenu)

### Anatomie

```
        ▲ (pointeur 12×12)
┌──────────────────────────────────┐
│  [Badge]  De confiance       ×30│  ← header
│           ARGENT · par les membres FOIS│
│                                  │
│  30 personnes t'ont marqué·e ... │  ← description
│                                  │
│  Dernière obtention : 12 mars 2026│  ← méta (si présent)
│                                  │
│  PROGRESSION         30 / 50     │
│  ████████████░░░░░░░░░░░░        │  ← barre vers tier suivant
│  Encore 20 pour Or               │
└──────────────────────────────────┘
```

### Specs

- **Largeur** : 280px (desktop) / 100% - 32px margins (mobile bottom sheet)
- **Background** : `#243752`
- **Border** : `1px solid rgba(<tier.ring>, 0.25)`
- **Border-radius** : 14px
- **Padding** : 14px
- **Pointeur** : carré 12×12, rotaté 45°, ancré sur le centre du badge tappé
- **Z-index** : 50
- **Animation d'apparition** : fade-in 120ms + scale 0.96 → 1 + translateY 4px → 0
- **Animation de fermeture** : inverse, 100ms

### Contenu

1. **Header** (display:flex, gap:12, marginBottom:10)
   - Mini badge (44px) à gauche
   - Bloc texte au milieu (flex:1) :
     - Titre (14px, weight 700)
     - Ligne meta : `<TIER_LABEL>` (10.5px, color = tier.ring, uppercase, letter-spacing 0.1em) · `par Junto` ou `par les membres` (10.5px, color text-dim)
   - Bloc compteur à droite : "×30" (18px, weight 800) + "FOIS" (9px, uppercase)

2. **Description** (12px, color text-dim, line-height 1.45, marginBottom 10)

3. **Méta dernière obtention** (si `badge.lastAt` présent) :
   - "Dernière obtention : <date>" — 10.5px, color text-muted

4. **Barre de progression** (sauf si `badge.negative === true` ou tier déjà Or) :
   - Header : "PROGRESSION" (gauche, 9.5px uppercase) + "30 / 50" (droite)
   - Track : 4px de hauteur, `rgba(255,255,255,0.08)`, border-radius 2px
   - Fill : largeur calculée, gradient du tier actuel
   - Caption : "Encore 20 pour [Argent|Or]" (10.5px) avec le label colorisé

5. **Si tier négatif** : un encart à la place de la progression :
   ```
   ┌──────────────────────────────────┐
   │ Ce signal apparaît dès la 1ʳᵉ    │
   │ occurrence et reste affiché 6 mois│
   └──────────────────────────────────┘
   ```
   Background `rgba(229, 82, 78, 0.08)`, border `rgba(229, 82, 78, 0.25)`, color `#E5524E`, padding 8, border-radius 8, font 10.5px.

### Calcul de la progression

```ts
function progressInTier(count: number): { pct: number; nextThreshold: number | null } {
  if (count < 10)  return { pct: (count / 10) * 100,         nextThreshold: 10 };
  if (count < 50)  return { pct: ((count - 10) / 40) * 100,  nextThreshold: 50 };
  return             { pct: 100, nextThreshold: null };
}
```

### Comportement (mobile vs desktop)

- **Desktop** : popover ancré sur le badge avec pointeur. Click outside → fermer.
- **Mobile (React Native)** : recommandé d'afficher comme **bottom sheet** plein largeur (le pointeur disparaît, le contenu reste identique). Drag-to-dismiss.

---

## 5. Intégration dans le profil

### Avant (existant)

Voir `uploads/profil_latest_1.jpeg` et `uploads/profile_latest_2.jpeg`. Bloc « Badges · 10 » avec :
- Sous-titre « Décernés par la commu » + 4 badges (50px, count en chip noire)
- Sous-titre « Décernés par Junto » + 6 badges
- Total = 2 lignes, badges grands, chiffres collés

### Après (cible)

Bloc « Badges · 10 » avec **une seule rangée** :

```
┌─────────────────────────────────────────────────────────┐
│  BADGES · 10                          •  •  •           │  ← header + légende mini-tiers (option)
│  ─────────────────────────────────────────────────       │
│                                                         │
│  ⊙   ⊙   ⊙   ⊙   ⊙   ⊙   ⊕                              │  ← 6 badges (40px) + bouton +N
│  De  Sup Bon Pon Rég Ani Voir                            │  ← labels (12px)
│  con… er… amb… ctu… ulier ma… tout                       │
│                                                         │
│  Touche un badge pour les détails                       │
└─────────────────────────────────────────────────────────┘
```

### Règles

| Règle | Détail |
| ----- | ------ |
| **Visible** | 6 badges max sur la rangée principale |
| **Tri** | (1) peer reviews positives d'abord, (2) Junto auto, (3) signaux négatifs **épinglés** en fin de rangée — jamais cachés derrière "+N" |
| **Au sein d'un groupe** | par `count` décroissant |
| **Overflow** | bouton circulaire pointillé "+N" + label "Voir tout" → ouvre l'écran "Voir tout" (cf. §6) |
| **Verrouillés** | n'apparaissent **pas** sur le profil ; visibles uniquement dans "Voir tout" |
| **Collisions de label** | si un badge se décline par discipline, **suffixer** : « Curieux Escalade », « Curieux Canyoning ». Plus jamais 3 « Curieux » identiques. |
| **Tap** | ouvre le popover/bottom sheet sur le badge tappé |

### Mots-clés à éviter

- ❌ "la commu" / "Décernés par la commu" → ✅ **"par les membres"** ou **"Décernés par les membres"**
- Chiffres "×N" superposés sur le badge → **supprimés** ; ils vivent dans le popover

---

## 6. Écran "Voir tout"

Au tap sur "+N / Voir tout" → écran plein viewport (ou modal full-screen sur mobile).

### Layout

- Titre : "Tous les badges"
- Sous-titre : "<X> obtenus / <Y> au total"
- Sections (chaque section avec son header + grille 4 colonnes, gap 16) :
  1. **Décernés par les membres** — peer review, triés par tier (Or → Argent → Bronze)
  2. **Décernés par Junto** — auto, mêmes règles de tri
  3. **Signaux** — si présents (séparés visuellement avec un divider rouge subtil)
  4. **À débloquer** — verrouillés (cercle pointillé, opacity 0.5), regroupés par catégorie

### Interaction

- Tap sur n'importe quel badge → popover/bottom sheet identique au profil
- Pas de pagination — scroll vertical naturel

---

## 7. Animation de promotion (bonus)

Quand un badge passe d'un tier à un autre (à la 10ᵉ ou 50ᵉ obtention) :

1. **Toast** en haut de l'écran : "Promu Argent — De confiance ✨" (durée 4s, swipe-to-dismiss)
2. Si l'utilisateur ouvre le profil dans les minutes suivantes, le badge concerné fait un **pulse** (scale 1 → 1.15 → 1, durée 600ms, easing `ease-out`) et son anneau **scintille** (opacity 0.5 → 1 → 0.5, infini jusqu'au premier tap).

À implémenter en deuxième pass — non bloquant pour le MVP.

---

## 8. Files

```
reference/
├── standalone.html    ← ⭐ ouvrir en premier — bundle auto-contenu, fonctionne offline
├── index.html         ← version source (charge React/Babel via CDN)
├── badges.jsx         ← composants Badge + Popover + tokens TIER + données SAMPLE_BADGES
├── profile-mocks.jsx  ← contexte d'intégration (avant/après)
└── app.jsx            ← page de présentation (canvas avec sections)

screenshots/
└── 01-states.png … 06-states.png  ← captures haute résolution des sections clés
```

**Sources principales pour le code** :
- `reference/badges.jsx` lignes 1–80 : `TIER` palette + `tierFor()` + `BADGE_ICON`
- `reference/badges.jsx` lignes 100–145 : `BadgeB` (variante retenue)
- `reference/badges.jsx` lignes 200–290 : `BadgePopoverRich` (popover retenu)

---

## 9. Checklist d'implémentation

- [ ] Créer le composant `<Badge>` (variante B) avec props `{ badge, size, showLabel, onTap }`
- [ ] Créer la fonction utilitaire `tierFor(count)`
- [ ] Créer la palette `TIER` dans le fichier de tokens existant
- [ ] Créer les 14 icônes SVG (paths fournis dans `BADGE_ICON`)
- [ ] Créer le composant `<BadgePopover>` avec barre de progression + état négatif
- [ ] Sur mobile : implémenter en bottom sheet
- [ ] Intégrer dans le profil : remplacer les deux rangées par une seule, sortir les chiffres des badges
- [ ] Tri : peer positifs → auto → négatifs épinglés, par count décroissant
- [ ] Renommer "la commu" / "Décernés par la commu" → "par les membres" / "Décernés par les membres" partout
- [ ] Suffixer les badges déclinés par discipline (ex: "Curieux Escalade")
- [ ] Bouton "+N / Voir tout" → écran "Voir tout"
- [ ] Écran "Voir tout" avec sections + verrouillés
- [ ] (V2) Toast de promotion + animation pulse
